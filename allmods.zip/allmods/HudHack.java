package ru.ShwepsikGG.Cleent.Modules;

import java.awt.Color;

import org.apache.commons.lang3.RandomUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.multiplayer.GuiConnecting;
import ru.ShwepsikGG.Botilka.Entity.EntityBot;
//import ru.ShwepsikGG.Botilka.EntityPlayerBot;
import ru.ShwepsikGG.Cleent.EClient;
import ru.ShwepsikGG.Cleent.BotSystem.BotModule;
import ru.ShwepsikGG.Cleent.HeroGui.util.TimerUtil;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class HudHack extends Module {

	public static Module mod;
	public HudHack() {
		super("HUD-Array", Keyboard.KEY_NONE, ModuleType.Render);
		mod = this;
	}
	
	public void onRender2D() {
		Minecraft mc = Minecraft.getMinecraft();
		ScaledResolution sr = new ScaledResolution(mc);
		TimerUtil time = new TimerUtil();
		GL11.glPushMatrix();
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		GL11.glEnable(GL11.GL_ALPHA_TEST);
		//bot sect
		int right = sr.getScaledWidth();
		int widthText = mc.fontRendererObj.getStringWidth("ExtremeBot: ");
		
		
		int height2 = 22;
		for(BotModule m : EClient.bmanager.getModules()) {
			if(m.isEnabled()) {
				height2 = height2 + 10;
				mc.fontRendererObj.drawStringWithShadow(m.getName(), right - mc.fontRendererObj.getStringWidth(m.getName()) - 5, height2 , Color.RED.hashCode());
			}
		
		} //right - mc.fontRendererObj.getStringWidth()
		mc.fontRendererObj.drawStringWithShadow("Bot count: " + EntityBot.bots.size(), right - mc.fontRendererObj.getStringWidth("Bot count " + EntityBot.bots.size()) - 5, 2, Color.GREEN.hashCode());
		mc.fontRendererObj.drawStringWithShadow("Threads: " + Thread.activeCount(), right - mc.fontRendererObj.getStringWidth("Threads: " + Thread.activeCount()) - 5 , 12, Color.CYAN.hashCode());
		mc.fontRendererObj.drawStringWithShadow("EBot mods: ", right - mc.fontRendererObj.getStringWidth("EBot mods: ") - 5, 22, Color.orange.hashCode());
		//bot end
		
		GL11.glScalef(1.4f, 1.4f, 1.4f);
		
		Color[] colors = {Color.CYAN, Color.BLUE, Color.RED, Color.GREEN, Color.WHITE, Color.PINK, Color.YELLOW, Color.DARK_GRAY};
		int index = RandomUtils.nextInt(0, colors.length);
		int randcolor = 0;
		if(time.check(1000L)) {
			randcolor = colors[index].hashCode();
			time.reset();
		}
		
		mc.fontRendererObj.drawStringWithShadow(EClient.clientName, 2, 2, randcolor);
		if(!mc.isSingleplayer()) {
			mc.fontRendererObj.drawStringWithShadow("Server: " + GuiConnecting.serverip, 2, 12, Color.CYAN.hashCode());
		} else {
			mc.fontRendererObj.drawStringWithShadow("Server: " + "integrated server", 2, 12, Color.RED.hashCode());
		}
		
		//EClient.manager.getModules().sort(Comparator.comparingInt(m -> mc.fontRendererObj.getStringWidth(((Module)m).getName())).reversed());
		int height = 15;
		for(Module m : EClient.manager.getModules()) {
			if(m.isEnabled()) {
				height = height + 10;
				mc.fontRendererObj.drawStringWithShadow(m.getName(), 2, height , 0xfffbbbff);
			}
		
		}
		
		
		GL11.glColor4f(1f, 1f, 1f, 1f);
		
		
		GL11.glPopMatrix();
	}
}
