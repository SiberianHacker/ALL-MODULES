package org.moonware.client.feature.impl.combat.particle;

public class TimeUtil {
}
