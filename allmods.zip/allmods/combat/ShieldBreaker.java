package Celestial.module.impl.Combat;

import Celestial.module.Module;
import Celestial.module.ModuleCategory;

public class ShieldBreaker extends Module {
    public ShieldBreaker() {
        super("ShieldBreaker", "Брякает щит противнику при включенной киллауре", ModuleCategory.Combat);
    }
}
