package wtf.expensive.modules.impl.combat;

import wtf.expensive.modules.Module;
import wtf.expensive.modules.ModuleAnnotation;
import wtf.expensive.modules.Type;

@ModuleAnnotation(name = "AutoExplosion", type = Type.COMBAT)
public class AutoExplosion extends Module {
}
