package wtf.expensive.modules.impl.combat;

import wtf.expensive.modules.Module;
import wtf.expensive.modules.ModuleAnnotation;
import wtf.expensive.modules.Type;

@ModuleAnnotation(name = "Keep Sprint", type = Type.COMBAT)
public class KeepSprintModule extends Module {
}
