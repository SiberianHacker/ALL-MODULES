package ru.dedinside.modules.impl.combat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import ru.dedinside.event.EventTarget;
import ru.dedinside.event.events.impl.EventUpdate;
import ru.dedinside.event.events.impl.ObsidianPlaceEvent;
import ru.dedinside.modules.Module;
import ru.dedinside.modules.ModuleAnnotation;
import ru.dedinside.modules.Type;
import ru.dedinside.util.math.TimerUtility;

@ModuleAnnotation(name = "Auto Explosion", desc = "������������� ������ ������� � �������� ���, �� �������� ������� �� ���������", type = Type.Combat)
public class AutoExplosionModule extends Module {

    public static TimerUtility timerHelper = new TimerUtility();
    private int counter;

    @EventTarget
    public void onObs(ObsidianPlaceEvent e) {
        final int oldSlot = mc.player.inventory.currentItem;
        final BlockPos pos = e.getPos();
        int crystal = getSlotIDFromItem(Items.END_CRYSTAL);
        if (crystal >= 0) { // da
            counter++;
            mc.player.inventory.currentItem = getSlotWithCrystal();
            mc.playerController.processRightClickBlock(mc.player, mc.world, pos, EnumFacing.UP, new Vec3d(pos.getX(), pos.getY(), pos.getZ()), EnumHand.MAIN_HAND);
            mc.player.swingArm(EnumHand.MAIN_HAND);
            mc.player.inventory.currentItem = oldSlot;
        }
    }
    @EventTarget
    public void update (EventUpdate e) {
        for (Entity entity : mc.world.loadedEntityList) {
            if (counter > 0) attackEntity(entity);
            if (!entity.isEntityAlive()) counter = 0;
        }
    }
    public void attackEntity(Entity base) {
        if (base instanceof EntityEnderCrystal) {
            if (base.isDead || mc.player.getDistance(base) > 6) {
                return;
            }
            if (timerHelper.hasTimeElapsed(200)) {
                mc.playerController.attackEntity(mc.player, base);
                mc.player.swingArm(EnumHand.MAIN_HAND);
                timerHelper.reset();
            }
        }
    }
    public int getSlotIDFromItem(Item item) {
        int slot = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack s = mc.player.inventory.getStackInSlot(i);
            if (s.getItem() == item) {
                slot = i;
                break;
            }
        }
        if (slot < 9 && slot != -1) {
            slot = slot + 36;
        }
        return slot;
    }

    private int getSlotWithCrystal() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.inventory.getStackInSlot(i).getItem() instanceof ItemEndCrystal) {
                return i;
            }
        }
        return -1;
    }
}
