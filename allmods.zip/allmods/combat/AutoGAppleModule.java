package ru.dedinside.modules.impl.combat;

import net.minecraft.init.Items;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemStack;
import ru.dedinside.event.EventTarget;
import ru.dedinside.event.events.impl.EventUpdate;
import ru.dedinside.modules.Module;
import ru.dedinside.modules.ModuleAnnotation;
import ru.dedinside.modules.Type;
import ru.dedinside.ui.dropui.setting.imp.SliderSetting;

@ModuleAnnotation(name = "AutoGApple", desc = "������������� ������ ����", type = Type.Combat)
public class AutoGAppleModule extends Module {
    public SliderSetting health = new SliderSetting("Health", 16, 1, 20, 1);
    boolean isEating;


    @EventTarget
    public void onUpdateEvent(EventUpdate eventUpdate) {

        if (isActive()) {
            isEating = true;
            mc.gameSettings.keyBindUseItem.pressed = true;
        } else if (isEating) {
            mc.gameSettings.keyBindUseItem.pressed = false;
            isEating = false;
        }
    }

    private boolean isActive() {
        float hp = mc.player.getHealth();
        return isGoldenApple(mc.player.getHeldItemOffhand()) && !mc.player.getCooldownTracker().hasCooldown(Items.GOLDEN_APPLE) && hp <= health.getFloatValue();
    }

    private boolean isGoldenApple(ItemStack stack) {
        return stack.getItem() == Items.GOLDEN_APPLE;
    }

}
