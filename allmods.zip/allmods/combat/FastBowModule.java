package ru.dedinside.modules.impl.combat;

import net.minecraft.item.ItemBow;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import ru.dedinside.event.EventTarget;
import ru.dedinside.event.events.impl.EventUpdate;
import ru.dedinside.modules.Module;
import ru.dedinside.modules.ModuleAnnotation;
import ru.dedinside.modules.Type;
import ru.dedinside.ui.dropui.setting.imp.SliderSetting;

@ModuleAnnotation(name = "FastBow", desc = "������� �������� �� ������� � ����", type = Type.Combat)
public class FastBowModule extends Module {
    private final SliderSetting ticks = new SliderSetting("Delay", 3.0f, 1.0f, 10, 0.5f);


    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        if (mc.player.inventory.getCurrentItem().getItem() instanceof ItemBow && mc.player.isHandActive()
                && mc.player.getItemInUseMaxCount() >= ticks.getFloatValue()) {
            mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM,
                    BlockPos.ORIGIN, mc.player.getHorizontalFacing()));
            mc.player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
            mc.player.stopActiveHand();
        }
    }
}
