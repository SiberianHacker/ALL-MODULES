package ru.dedinside.modules.impl.combat;

import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import ru.dedinside.event.EventTarget;
import ru.dedinside.event.events.impl.EventUpdate;
import ru.dedinside.modules.Module;
import ru.dedinside.modules.ModuleAnnotation;
import ru.dedinside.modules.Type;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@ModuleAnnotation(name = "AntiBot", desc = "������� ����� ������� ���������� �������", type = Type.Combat)
public class AntiBotModule extends Module {

    public static List<Entity> isBotPlayer = new ArrayList<>();


    @EventTarget
    public void onUpdate(EventUpdate eventUpdate) {
        for (Entity entity : mc.world.playerEntities) {
            if (!entity.getUniqueID().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + entity.getName()).getBytes(StandardCharsets.UTF_8))) && entity instanceof EntityOtherPlayerMP) {
                isBotPlayer.add(entity);
            }
            if (!entity.getUniqueID().equals(UUID.nameUUIDFromBytes(("OfflinePlayer:" + entity.getName()).getBytes(StandardCharsets.UTF_8))) && entity.isInvisible() && entity instanceof EntityOtherPlayerMP) {
                mc.world.removeEntity(entity);
            }
        }
    }

    @Override
    public void onDisable() {
        isBotPlayer.clear();
    }
}
