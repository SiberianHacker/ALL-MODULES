package me.independed.inceptice.modules.combat;

class EntitySize {
      public float height;
      public float width;

      public EntitySize(float var1, float var2) {
            this.width = var1;
            if ((889559765 >> 1 << 4 ^ -1473456480) == 0) {
                  ;
            }

            this.height = var2;
      }
}
