package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class LiftHack extends Module {

	public LiftHack() {
		super("LiftHack", Keyboard.KEY_F, ModuleType.Player);
	}
	
	public void onUpdate() {
		Minecraft mc = Minecraft.getMinecraft();
		mc.player.jump();
	}
}
