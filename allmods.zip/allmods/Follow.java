package rawfish2d.client.pbot.modules;

import net.minecraft.client.Minecraft;
import rawfish2d.client.lua.LuaAPI;
import rawfish2d.client.modulebase.ModuleType;
import rawfish2d.client.pbot.PBot;
import rawfish2d.client.pbot.modulebase.PBotModuleBase;

public class Follow extends PBotModuleBase {
    public static final Minecraft mc = Minecraft.getMinecraft();
    public Follow(String name, String desc, int keybind, ModuleType type, final PBot pbot) {
        super(name, desc, keybind, type, pbot);

    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    public void onPreUpdate() {
        String targetName = mc.getMinecraft().getSession().getUsername();
        LuaAPI.instance.facePlayer(pbot.getNickname(), targetName);
    }
}
