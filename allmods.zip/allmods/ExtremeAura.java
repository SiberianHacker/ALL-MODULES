package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.MathHelper;
import ru.ShwepsikGG.Cleent.EClient;
import ru.ShwepsikGG.Cleent.HeroGui.Setting;
import ru.ShwepsikGG.Cleent.HeroGui.util.ChatUtils;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class ExtremeAura extends Module
{
    public static int preset;
    public static int preset1;
    public static int speedBars;
    public static int reachBars;
    public static int defaultreach;
    public static int defaultspeed;
    public static int teslareach;
    public static int teslaspeed;
    
    static {
        ExtremeAura.speedBars = -2;
        ExtremeAura.reachBars = 6;
        ExtremeAura.defaultreach = 5;
        ExtremeAura.defaultspeed = -3;
        ExtremeAura.teslareach = 4;
        ExtremeAura.teslaspeed = -4;
    }
    
    public ExtremeAura() {
        super("ExtremeAura", Keyboard.KEY_NONE, ModuleType.Player);
        EClient.setMgr.rSetting(new Setting("Chat", this, false));
        EClient.setMgr.rSetting(new Setting("Mobs", this, false));
        EClient.setMgr.rSetting(new Setting("Invises", this, false));
        EClient.setMgr.rSetting(new Setting("Packet rotate", this, false));
    }
    
    public void onEnable() {
    }
    
    public void onDisable() {
    }
    
    public void onUpdate() {
        final boolean chat = EClient.setMgr.getSettingByName("Chat").getValBoolean();
        final boolean protate = EClient.setMgr.getSettingByName("Packet rotate").getValBoolean();
        final Minecraft mc = Minecraft.getMinecraft();
        final GameSettings gameSettings = mc.gameSettings;
        GameSettings.isKeyDown(mc.gameSettings.keyBindForward);
        for (final Entity ent : mc.world.loadedEntityList) {
            if (this.checks(ent)) {
                final EntityLivingBase en = (EntityLivingBase)ent;
                if (protate) {
                    faceEntity(en);
                }
                mc.playerController.attackEntity(mc.player, en);
                mc.player.swingArm(EnumHand.MAIN_HAND);
                if (!chat) {
                    continue;
                }
                ChatUtils.cmd(String.valueOf(ChatUtils.cyan) + ChatUtils.l + "Attacking " + en.getName() + " hp = " + en.getHealth() / 2.0f);
            }
        }
    }
    
    boolean checks(final Entity en) {
        final boolean mobs = EClient.setMgr.getSettingByName("Mobs").getValBoolean();
        final boolean invis = EClient.setMgr.getSettingByName("Invises").getValBoolean();
        final Minecraft mc = Minecraft.getMinecraft();
        if (!(en instanceof EntityLivingBase)) {
            return false;
        }
        if (en == mc.player) {
            return false;
        }
        if (mobs) {
            if (!(en instanceof EntityPlayer)) {
                return true;
            }
        }
        else if (!mobs && !(en instanceof EntityPlayer)) {
            return false;
        }
        if (en.isDead) {
            return false;
        }
        if (en.getDistanceToEntity(mc.player) > 4.5) {
            return false;
        }
        if (en.getName().contains("\u041c\u0410\u0413\u0410\u0417\u0418\u041d")) {
            return false;
        }
        if (en.getName().contains("ShwepsikGG")) {
            return false;
        }
        if (mc.player.getCooledAttackStrength((float)1) < 1.0f) {
            return false;
        }
        if (invis) {
            if (en.isInvisibleToPlayer(mc.player)) {
                return true;
            }
            if (!invis && en.isInvisibleToPlayer(mc.player)) {
                return false;
            }
        }
        return true;
    }
    
    public static synchronized void faceEntity(final Entity entity) {
        final float[] rotations = getRotationsNeeded(entity);
        if (rotations != null) {
            final Minecraft mc = Minecraft.getMinecraft();
            mc.player.connection.sendPacket(new CPacketPlayer.Rotation(rotations[0], rotations[1], mc.player.onGround));
        }
    }
    
    public static float[] getRotationsNeeded(final Entity entity) {
        if (entity == null) {
            return null;
        }
        final double diffX = entity.posX - Minecraft.getMinecraft().player.posX;
        final double diffZ = entity.posZ - Minecraft.getMinecraft().player.posZ;
        double diffY;
        if (entity instanceof EntityPlayer) {
            final EntityPlayer entityLivingBase = (EntityPlayer)entity;
            diffY = entityLivingBase.posY + entityLivingBase.getEyeHeight() - (Minecraft.getMinecraft().player.posY + Minecraft.getMinecraft().player.getEyeHeight());
        }
        else if (entity instanceof EntityMob) {
            final EntityMob entityLivingBase2 = (EntityMob)entity;
            diffY = (entity.boundingBox.minY + entity.boundingBox.maxY) / 1.0 - (Minecraft.getMinecraft().player.posY + Minecraft.getMinecraft().player.getEyeHeight());
        }
        else {
            final EntityLivingBase entityLivingBase3 = (EntityLivingBase)entity;
            diffY = (entity.boundingBox.minY + entity.boundingBox.maxY) / 1.0 - (Minecraft.getMinecraft().player.posY + Minecraft.getMinecraft().player.getEyeHeight());
        }
        final double dist = MathHelper.sqrt(diffX * diffX + diffZ * diffZ);
        final float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 95.0f;
        final float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / 3.141592653589793));
        return new float[] { Minecraft.getMinecraft().player.rotationYaw + MathHelper.wrapDegrees(yaw - Minecraft.getMinecraft().player.rotationYaw), Minecraft.getMinecraft().player.rotationPitch + MathHelper.wrapDegrees(pitch - Minecraft.getMinecraft().player.rotationPitch) };
    }
}
