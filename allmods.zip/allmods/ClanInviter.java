package ru.ShwepsikGG.Cleent.Modules;

import java.util.List;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import ru.ShwepsikGG.Cleent.BotGui.components.TimeHelper;
import ru.ShwepsikGG.Cleent.HeroGui.util.ChatUtils;
import ru.ShwepsikGG.Cleent.HeroGui.util.RandomUtils;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class ClanInviter extends Module {

	public ClanInviter() {
		super("Clan Inviter", Keyboard.KEY_NONE, ModuleType.Fun);
	}
	public TimeHelper help = new TimeHelper();
	
	
	public void onUpdate() {
		 final NetHandlerPlayClient nethandlerplayclient1 = this.mc.player.connection;
	        final List<NetworkPlayerInfo> list1 = (List<NetworkPlayerInfo>)GuiPlayerTabOverlay.ENTRY_ORDERING.sortedCopy((Iterable)nethandlerplayclient1.getPlayerInfoMap());
	        final String nickname = list1.get(RandomUtils.nextInt(1, nethandlerplayclient1.getPlayerInfoMap().size())).getGameProfile().getName();
	        if (this.help.check(1000.0f)) {
	            ChatUtils.success(String.valueOf(ChatUtils.green) + "Inviting : " + ChatUtils.Dgreen + nickname);
	            if (nickname.contains("§")) {
	                return;
	            }
	            if (nickname.contains(this.mc.player.getName())) {
	                return;
	            }
	            mc.player.sendChatMessage("/clan invite " + nickname);
	            this.help.reset();
	        }
	    }
	}
