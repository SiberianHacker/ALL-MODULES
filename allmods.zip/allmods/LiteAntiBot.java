package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;

import net.minecraft.entity.Entity;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class LiteAntiBot extends Module {

	public LiteAntiBot() {
		super("LiteAntiBot", Keyboard.KEY_NONE, ModuleType.Player);
	}
	
	public void onUpdate() {
		if (mc.player == null || mc.world == null) {
            return;
        }
        for (Entity entity : mc.world.loadedEntityList) {
            if (entity == null || !(entity instanceof net.minecraft.entity.item.EntityArmorStand))
                continue;
            mc.world.removeEntity(entity);
        }
	}

}
