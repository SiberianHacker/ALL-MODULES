package rawfish2d.client.pbot.modules;

import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import rawfish2d.client.modulebase.ModuleType;
import rawfish2d.client.pbot.PBot;
import rawfish2d.client.pbot.modulebase.PBotModuleBase;
import rawfish2d.client.utils.CombatUtils;

public class AutoArmor extends PBotModuleBase {

	private boolean boots;
	private boolean pants;
	private boolean chest;
	private boolean hat;

	int[] bootsID = { 313, 309, 305, 317, 301 };
	int[] pantsID = { 312, 308, 304, 316, 300 };
	int[] chestID = { 311, 307, 303, 315, 299 };
	int[] hatsID = { 310, 306, 302, 314, 298 };
	int prevSlot = -1;

	public AutoArmor(String name, String desc, int keybind, ModuleType type, final PBot pbot) {
		super(name, desc, keybind, type, pbot);
	}

	@Override
	public void onPreUpdate() {
		try {
			ItemStack[] arr_armor = new ItemStack[4];

			arr_armor[0] = pbot.player.inventory.armorInventory.get(0);
			arr_armor[1] = pbot.player.inventory.armorInventory.get(1);
			arr_armor[2] = pbot.player.inventory.armorInventory.get(2);
			arr_armor[3] = pbot.player.inventory.armorInventory.get(3);

			if (arr_armor[0].getItem().getID() == 0) {
				boots = false;
			} else {
				boots = true;
			}

			if (arr_armor[1].getItem().getID() == 0) {
				pants = false;
			} else {
				pants = true;
			}

			if (arr_armor[2].getItem().getID() == 0) {
				chest = false;
			} else {
				chest = true;
			}

			if (arr_armor[3].getItem().getID() == 0) {
				hat = false;
			} else {
				hat = true;
			}
			/*
			pbot.botInfoPrint("boots: " + boots);
			pbot.botInfoPrint("pants: " + pants);
			pbot.botInfoPrint("chest: " + chest);
			pbot.botInfoPrint("hat: " + hat);
			*/
			equipNewArmor();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
    }

	public void setInvSlot(int slot) {
		pbot.changeSlot(slot);
	}

	public void click(int slot, int mode) {
		// pbot.botInfoPrint("click slot: " + slot);
		// mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slot, 0, mode, mc.player);
		pbot.mc.playerController.windowClick(pbot.player.inventoryContainer.windowId, slot, 0, ClickType.QUICK_MOVE, pbot.player);
	}

	public void sendItemUse(ItemStack itemStack) {
		// pbot.mc.rightClickMouse();
		EnumActionResult result = pbot.mc.playerController.processRightClick(this.pbot.player, this.pbot.getWorld(), EnumHand.MAIN_HAND);
		// pbot.botInfoPrint("sendItemUse: " + itemStack.getDisplayName() + " id: " + itemStack.getID() + " result: " + result);
		// mc.playerController.sendSlotPacket(itemStack, pbot.player.inventory.currentItem);
	}

	private void equipNewArmor() {
		// ItemStack[] arr_inv = mc.player.inventory.mainInventory;
		NonNullList<ItemStack> list = pbot.player.inventory.mainInventory;
		ItemStack[] arr_inv = new ItemStack[list.size()];

		int index = 0;
		for (ItemStack stack : list) {
			arr_inv[index] = stack;
		}

		// equip boots
		if (!boots) {
			boolean hot = false;
			boolean inv = false;

			int slot = -1;
			for (int id : bootsID) {
				int invSlot = CombatUtils.getSlotByID(pbot, id);
				if (invSlot != -1) {
					inv = true;
					slot = invSlot;
					break;
				} else {
					int newSlot = CombatUtils.getSlotOfHotbarItem(pbot, id);
					if (newSlot != -1) {
						hot = true;
						slot = newSlot;
						break;
					}
				}
			}

			if (slot != -1 && inv) {
				// pbot.botInfoPrint("click: " + slot);
				click(slot, 1);
			} else if (slot != -1 && hot) {
				prevSlot = pbot.player.inventory.currentItem;

				// pbot.botInfoPrint("sendItemUse: " + slot);
				ItemStack currentItemStack = pbot.player.inventory.mainInventory.get(prevSlot);

				setInvSlot(slot);
				sendItemUse(currentItemStack);
			}
			// pbot.botInfoPrint("wtf slot:" + slot + " inv: " + inv + " hot: " + hot);
		}

		// equip pants
		if (!pants) {
			boolean hot = false;
			boolean inv = false;

			int slot = -1;
			for (int id : pantsID) {
				int invSlot = CombatUtils.getSlotByID(pbot, id);
				if (invSlot != -1) {
					inv = true;
					slot = invSlot;
					break;
				} else {
					int newSlot = CombatUtils.getSlotOfHotbarItem(pbot, id);
					if (newSlot != -1) {
						hot = true;
						slot = newSlot;
						break;
					}
				}
			}

			if (slot != -1 && inv) {
				// pbot.botInfoPrint("click: " + slot);
				click(slot, 1);
			} else if (slot != -1 && hot) {
				prevSlot = pbot.player.inventory.currentItem;

				// pbot.botInfoPrint("sendItemUse: " + slot);
				ItemStack currentItemStack = pbot.player.inventory.mainInventory.get(prevSlot);

				setInvSlot(slot);
				sendItemUse(currentItemStack);
			}
		}

		// equip chest
		if (!chest) {
			boolean hot = false;
			boolean inv = false;

			int slot = -1;
			for (int id : chestID) {
				int invSlot = CombatUtils.getSlotByID(pbot, id);
				if (invSlot != -1) {
					inv = true;
					slot = invSlot;
					break;
				} else {
					int newSlot = CombatUtils.getSlotOfHotbarItem(pbot, id);
					if (newSlot != -1) {
						hot = true;
						slot = newSlot;
						break;
					}
				}
			}

			if (slot != -1 && inv) {
				// pbot.botInfoPrint("click: " + slot);
				click(slot, 1);
			} else if (slot != -1 && hot) {
				prevSlot = pbot.player.inventory.currentItem;

				// pbot.botInfoPrint("sendItemUse: " + slot);
				ItemStack currentItemStack = pbot.player.inventory.mainInventory.get(prevSlot);

				setInvSlot(slot);
				sendItemUse(currentItemStack);
			}
		}

		// equip hat
		if (!hat) {
			boolean hot = false;
			boolean inv = false;

			int slot = -1;
			for (int id : hatsID) {
				int invSlot = CombatUtils.getSlotByID(pbot, id);
				if (invSlot != -1) {
					inv = true;
					slot = invSlot;
					break;
				} else {
					int newSlot = CombatUtils.getSlotOfHotbarItem(pbot, id);
					if (newSlot != -1) {
						hot = true;
						slot = newSlot;
						break;
					}
				}
			}

			if (slot != -1 && inv) {
				// pbot.botInfoPrint("click: " + slot);
				click(slot, 1);
			} else if (slot != -1 && hot) {
				prevSlot = pbot.player.inventory.currentItem;

				// pbot.botInfoPrint("sendItemUse: " + slot);
				ItemStack currentItemStack = pbot.player.inventory.mainInventory.get(prevSlot);

				setInvSlot(slot);
				sendItemUse(currentItemStack);
			}
		}
	}
}
