package ru.ShwepsikGG.Cleent.Modules;

import org.apache.commons.lang3.RandomUtils;
import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketCreativeInventoryAction;
import ru.ShwepsikGG.Cleent.CommandManager;
import ru.ShwepsikGG.Cleent.HeroGui.util.TimerUtil;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class FlexerMini extends Module {

	public TimerUtil time;
	
	public FlexerMini() {
		super("FlexerMini", Keyboard.KEY_NONE, ModuleType.Fun);
		time = new TimerUtil();
	}
	
	public void onEnable() {
		
	}
	
	public void onDisable() {
		
	}
	
	public void onUpdate() {
		Minecraft mc = Minecraft.getMinecraft();
		if(!mc.playerController.isNotCreative()) {
			if (time.check(100L)) {
				mc.player.connection.sendPacket(new CPacketCreativeInventoryAction(5, new ItemStack(Item.getItemById(35), 1, RandomUtils.nextInt(1, 15))));
				time.reset();
			}
		} else {
			CommandManager.showMessageWithPrefix("Включите креатив режим!");
			this.toggle();
		}
	}

}
