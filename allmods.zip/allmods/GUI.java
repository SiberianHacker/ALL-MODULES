package ru.ShwepsikGG.Cleent.Modules;
import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import ru.ShwepsikGG.Cleent.CommandManager;
import ru.ShwepsikGG.Cleent.EClient;
import ru.ShwepsikGG.Cleent.HeroGui.ClickGUI;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class GUI extends Module{

	public GUI() {
		super("GUI", Keyboard.KEY_GRAVE, ModuleType.Render);
		// TODO Auto-generated constructor stub
	}
	
	Minecraft mc = Minecraft.getMinecraft();
	
	public void onEnable() {
		this.toggle();
		mc.displayGuiScreen(new ClickGUI());
	}
	

}
