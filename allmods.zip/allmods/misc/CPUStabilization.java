package org.moonware.client.feature.impl.misc;

import org.moonware.client.feature.Feature;
import org.moonware.client.feature.impl.Type;

public class CPUStabilization
        extends Feature {
    public CPUStabilization() {
        super("CPUStabilization", "\u0423\u043c\u0435\u043d\u044c\u0448\u0430\u0435\u0442 \u0444\u043f\u0441 \u043f\u0440\u0438 \u0441\u0432\u0435\u0440\u043d\u0443\u0442\u043e\u0439 \u0438\u0433\u0440\u0435, \u0447\u0442\u043e\u0431\u044b \u044d\u043a\u043e\u043d\u043e\u043c\u0438\u0442\u044c \u0440\u0435\u0441\u0443\u0440\u0441\u044b \u041f\u041a", Type.Other);
    }
}
