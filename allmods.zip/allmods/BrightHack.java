package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class BrightHack extends Module {

	public BrightHack() {
		super("BrightHack", Keyboard.KEY_O, ModuleType.Render);
	}
	
	float gamma;
	
	public void onEnable() {
		Minecraft mc = Minecraft.getMinecraft();
		gamma = mc.gameSettings.gammaSetting;
		mc.gameSettings.gammaSetting = 1000000f;
	}
	
	public void onDisable() {
		Minecraft mc = Minecraft.getMinecraft();
		mc.gameSettings.gammaSetting = gamma;
	}
}
