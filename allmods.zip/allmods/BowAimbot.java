package ru.ShwepsikGG.Cleent.Modules;

import java.util.Iterator;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBow;
import ru.ShwepsikGG.Cleent.HeroGui.util.MatanHelper;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class BowAimbot extends Module {
public Entity target;
public double resolveX;
public double resolveZ;
	public BowAimbot() {
		super("BowAIMBOT", Keyboard.KEY_NONE, ModuleType.Player);
	}
	
	   public void onUpdate() {
		  for(Entity en : mc.world.loadedEntityList) {
			  if(isValid(en) && en instanceof EntityPlayer) {
				  this.target = en;
			      if (en != null && this.mc.player.getActiveItemStack().getItem() instanceof ItemBow) {
			         this.rotate();
			      }
			  }
		  }

	   }

	   public boolean isValid(Entity e) {
	      if (e == this.mc.player) {
	         return false;
	      } else if (e instanceof EntityPlayer) {
	         return true;
	      } else {
	         return this.mc.player.getDistanceToEntity(e) < 50.0F;
	      }
	   }

	   public void rotate() {
	      this.resolveX = MatanHelper.interpolate((this.target.posX - this.target.prevPosX) * 3.0D, this.resolveX, 0.1D);
	      this.resolveZ = MatanHelper.interpolate((this.target.posZ - this.target.prevPosZ) * 3.0D, this.resolveZ, 0.1D);
	      double x = this.target.posX - this.mc.player.posX + (this.target.posX - this.target.prevPosX == 0.0D ? 0.0D : this.resolveX);
	      double y = this.target.posY - this.mc.player.posY + (double)(this.mc.player.getDistanceToEntity(this.target) / 25.0F) + Math.abs(this.target.posY - this.target.prevPosY);
	      double z = this.target.posZ - this.mc.player.posZ + (this.target.posZ - this.target.prevPosZ == 0.0D ? 0.0D : this.resolveZ);
	      double yaw = Math.atan2(z, x);
	      double pitch = net.minecraft.util.math.MathHelper.clamp(Math.atan2(y, Math.sqrt(x * x + z * z)), -90.0D, 90.0D);
	      mc.player.rotationYaw = ((float)(Math.toDegrees(yaw) - 90.0D));
	      mc.player.rotationPitch = (-((float)Math.toDegrees(pitch)));
	   }
	}
