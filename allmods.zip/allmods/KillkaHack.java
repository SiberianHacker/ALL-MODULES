package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import ru.ShwepsikGG.Cleent.HeroGui.util.TimerUtil;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class KillkaHack extends Module {

	public TimerUtil time;
	
	public KillkaHack() {
		super("1.8 Aura", Keyboard.KEY_NONE, ModuleType.Player);
	}
	
	public void onEnable() {
		
	}
	
	public void onDisable() {
		
	}
	
	public void onUpdate() {
		Minecraft mc = Minecraft.getMinecraft();
		for (Entity ent : mc.world.getLoadedEntityList()) {
			if(ent != mc.player && (mc.player.getDistanceToEntity(ent) < 5)) {
				if(time.check(500L)) {
					mc.playerController.attackEntity(mc.player, ent);
					time.reset();
				}
			}
		}
	}

}
