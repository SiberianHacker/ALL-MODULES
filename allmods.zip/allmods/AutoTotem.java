package rawfish2d.client.pbot.modules;

import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import rawfish2d.client.modulebase.ModuleType;
import rawfish2d.client.pbot.PBot;
import rawfish2d.client.pbot.modulebase.PBotModuleBase;

public class AutoTotem extends PBotModuleBase {
	public AutoTotem(String name, String desc, int keybind, ModuleType type, final PBot pbot) {
		super(name, desc, keybind, type, pbot);
	}

	@Override
	public void onPreUpdate() {
		try {
			equipTotem();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
    }

	public void setInvSlot(int slot) {
		pbot.changeSlot(slot);
	}

	public int getSlotByID(int id) {
		for (int a = 9; a < 36; ++a) {
			ItemStack is = pbot.player.inventoryContainer.getSlot(a).getStack();
			if (is != null && is.getItem().getID() == id) {
				return a;
			}
		}
		return -1;
	}

	public int getSlotOfHotbarItem(int id) {
		for (int a = 0; a < 9; a++) {
			ItemStack is = pbot.player.inventory.getStackInSlot(a);
			if (is != null && is.getItem().getID() == id) {
				return a;
			}
		}
		return -1;
	}

	private void equipTotem() {
		// ItemStack[] arr_inv = mc.player.inventory.mainInventory;
		// auto totem
		boolean totem = true;
		int totemID = 449;
		int totemSlot = 45;
		int itemIDInOffHand = 0;
		ItemStack itemStack = pbot.player.inventory.offHandInventory.get(0);
		if (itemStack != null) {
			itemIDInOffHand = itemStack.getID();
			if (itemIDInOffHand != totemID) {
				totem = false;
			}
		}

		if (!totem) {
			int invSlot = -1;
			invSlot = getSlotByID(totemID);

			if (invSlot == -1) {
				invSlot = getSlotOfHotbarItem(totemID) + 36;
			}

			if (invSlot - 36 != -1) {
				int winID = pbot.currentWindowID();
				if (itemIDInOffHand == 0) {
					pbot.mc.playerController.windowClick(winID, invSlot, 0, ClickType.PICKUP, pbot.player);
					pbot.mc.playerController.windowClick(winID, totemSlot, 0, ClickType.PICKUP, pbot.player);
				} else {
					pbot.mc.playerController.windowClick(winID, totemSlot, 0, ClickType.QUICK_MOVE, pbot.player);
					pbot.mc.playerController.windowClick(winID, invSlot, 0, ClickType.PICKUP, pbot.player);
					pbot.mc.playerController.windowClick(winID, totemSlot, 0, ClickType.PICKUP, pbot.player);
				}
			}
		}
	}
}
