package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;

import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class AntiKnockBack extends Module {
	
	String kek = "luybly nuyhat trusi svoei devushki";
	public AntiKnockBack() {
		super("Антикнокбек", Keyboard.KEY_NONE, ModuleType.Player);
	}
	

}
