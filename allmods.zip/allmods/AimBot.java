package rawfish2d.client.pbot.modules;

import net.minecraft.entity.Entity;
import rawfish2d.client.modulebase.ModuleType;
import rawfish2d.client.pbot.PBot;
import rawfish2d.client.pbot.modulebase.PBotModuleBase;
import rawfish2d.client.utils.CombatUtils;
import rawfish2d.client.utils.RotationUtils;
import rawfish2d.utils.BoolValue;
import rawfish2d.utils.DoubleValue;

public class AimBot extends PBotModuleBase {
	public BoolValue onKey;
	public DoubleValue range;
	public DoubleValue fov;

	public AimBot(String name, String desc, int keybind, ModuleType type, PBot pbot) {
		super(name, desc, keybind, type, pbot);

		onKey = new BoolValue(false);
		range = new DoubleValue(12f, 0f, 30f);
		fov = new DoubleValue(180f, 0f, 361f);
		/*
		elements.add(new CheckBox(this, "On key", onKey, 0, 0));
		elements.add(new NewSlider(this, "Range", range, 0, 10, false));
		elements.add(new NewSlider(this, "FOV", fov, 0, 30, false));
		*/
	}

	@Override
	public void onEnable() {

	}

	@Override
	public void onDisable() {

	}

	@Override
	public void onRender() {

	}

	@Override
	public void onPreUpdate() {
		/*
		if(pbot.mc.gameSettings.keyBindAttack.pressed && onKey.getValue() || !onKey.getValue()) {
			Entity target = CombatUtils.getClosestTarget(fov.getValue(), range.getValue(), false, pbot.world, pbot.player);
		
			if(target != null) {
				target = CombatUtils.getClosestTarget(fov.getValue(), range.getValue(), false, pbot.world, pbot.player);
				RotationUtils.facePlayer(target, false, pbot.player);
			}
		}
		*/
		Entity target = CombatUtils.getClosestTarget(fov.getValue(), range.getValue(), false, pbot.getWorld(), pbot.player);

		if (target != null) {
			// target = CombatUtils.getClosestTarget(fov.getValue(), range.getValue(), false, pbot.world, pbot.player);
			RotationUtils.facePlayer(target, false, pbot.player);
		}
    }
}
