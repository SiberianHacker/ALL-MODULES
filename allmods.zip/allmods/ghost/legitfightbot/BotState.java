package dev.rise.module.impl.ghost.legitfightbot;

public enum BotState {
    GENERAL,
    BRIDGE
}
