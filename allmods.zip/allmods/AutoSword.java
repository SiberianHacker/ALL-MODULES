package rawfish2d.client.pbot.modules;

import rawfish2d.client.modulebase.ModuleType;
import rawfish2d.client.pbot.PBot;
import rawfish2d.client.pbot.modulebase.PBotModuleBase;
import rawfish2d.client.utils.CombatUtils;

public class AutoSword extends PBotModuleBase {

	public AutoSword(String name, String desc, int keybind, ModuleType type, final PBot pbot) {
		super(name, desc, keybind, type, pbot);
	}

	@Override
	public void onPreUpdate() {
		try {
			if (pbot.player.isSwingInProgress) {
				CombatUtils.getBestWeapon(pbot);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
    }
}
