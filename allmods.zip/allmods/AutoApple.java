package rawfish2d.client.pbot.modules;

import rawfish2d.client.modulebase.ModuleType;
import rawfish2d.client.pbot.PBot;
import rawfish2d.client.pbot.modulebase.PBotModuleBase;
import rawfish2d.client.utils.CombatUtils;

public class AutoApple extends PBotModuleBase {

	public AutoApple(String name, String desc, int keybind, ModuleType type, final PBot pbot) {
		super(name, desc, keybind, type, pbot);
	}

	@Override
	public void onPreUpdate() {
		/*
		try {
			if(pbot.mc.playerController.isInCreativeMode())
				return;
			
			ItemStack curStack = pbot.player.inventory.mainInventory.get(pbot.player.inventory.currentItem);
			if (shouldEat()) {
				CombatUtils.getApple(pbot);
				
				if (CombatUtils.isGoldenApple(curStack)) {
					pbot.mc.gameSettings.keyBindUseItem.pressed = true;
					pbot.mc.playerController.processRightClick(pbot.player, pbot.world, EnumHand.MAIN_HAND);
				}
			} else if (!shouldEat() && CombatUtils.isGoldenApple(curStack)) {
				pbot.mc.gameSettings.keyBindUseItem.pressed = false;
				//pbot.mc.playerController.onStoppedUsingItem(pbot.player);
				//CombatUtils.getBestWeaponClient();
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		*/
    }

	public boolean shouldEat() {
		// if Regeneration or Absorption is active
		return !(CombatUtils.isPotionActive(pbot, 10) || CombatUtils.isPotionActive(pbot, 22));
	}
}
