package rawfish2d.client.pbot.modules;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import rawfish2d.client.Client;
import rawfish2d.client.modulebase.ModuleType;
import rawfish2d.client.pbot.PBot;
import rawfish2d.client.pbot.modulebase.PBotModuleBase;
import rawfish2d.client.utils.CombatUtils;
import rawfish2d.client.utils.MiscUtils;
import rawfish2d.client.utils.RotationUtils;
import rawfish2d.utils.BoolValue;
import rawfish2d.utils.DoubleValue;
import rawfish2d.utils.TimeHelper;

public class KillAura extends PBotModuleBase {
	private BoolValue legit;
	private BoolValue silent;
	private DoubleValue speed;
	private DoubleValue range;
	private DoubleValue angle;
	private BoolValue closestMode;
	private Entity curTarget;
	private TimeHelper time;
	private BoolValue runToTarget;
	public static boolean useClientList = true;

	public KillAura(String name, String desc, int keybind, ModuleType type, final PBot pbot) {
		super(name, desc, keybind, type, pbot);

		legit = new BoolValue(false);
		silent = new BoolValue(false);
		speed = new DoubleValue(4, 1, 30);
		range = new DoubleValue(6.0, 1, 7);
		angle = new DoubleValue(360.0, 1, 360.0);
		closestMode = new BoolValue(false);
		runToTarget = new BoolValue(false);

		curTarget = null;
		time = new TimeHelper();
		// from UltimateHack and from Smuff (1.5.2)
	}

	@Override
	public void onEnable() {

	}

	@Override
	public void onDisable() {
		if (runToTarget.getValue()) {
			pbot.mc.gameSettings.keyBindSprint.pressed = false;
			pbot.mc.gameSettings.keyBindForward.pressed = false;
			pbot.mc.gameSettings.keyBindJump.pressed = false;
			pbot.mc.gameSettings.keyBindForward.pressed = false;
		}
	}

	@Override
	public void onPreUpdate() {
		if (!Client.debug) {
			boolean useClientEntityList = true;
			World world = pbot.getWorld();
			if (useClientEntityList) {
				world = Client.mc.world;
			}
			runToTarget.setValue(true);

			float frange = (float) range.getValue();
			frange = 128;

			if (closestMode.getValue()) {
				curTarget = CombatUtils.getClosestTarget(angle.getValue(), frange, legit.getValue(), world, pbot.player);
			} else {
				curTarget = CombatUtils.getTarget(angle.getValue(), frange, legit.getValue(), world, pbot.player);
			}
			double dist = 9999;

			List<EntityPlayer> ents = new ArrayList<EntityPlayer>();

			float xLimit = -216; // -216

			List<Entity> worldEnts = new ArrayList<Entity>();
			try {
				for (Entity e : world.playerEntities) {
					worldEnts.add(e);
				}
			} catch (Exception ex) {
				return;
			}

			for (Entity ent : worldEnts) {
				if (ent instanceof EntityPlayer) {
					if (!ent.getName().contains(Client.getName()) && ent.posX > xLimit &&
							// !ent.getName().contains("misha1234") &&
							// !ent.getName().contains("qwst123") &&
							!ent.getName().contains("Kpox")

						// && !ent.getName().contains("LoveMinecraft031")

						// && !ent.getName().contains("vovapilevin2")
						// && !ent.getName().contains("AFFF")

					) {
						ents.add((EntityPlayer) ent);
					}
				}
			}

			for (EntityPlayer ent : ents) {
				if (ent.posX > xLimit && ent.getEntityId() != pbot.player.getEntityId()) {
					double value = ent.getDistanceToEntity(pbot.player);
					if (ent.getDistanceToEntity(pbot.player) < dist) {
						PBot pbot = PBot.getBot(ent.getName());
						if (pbot != null)
							continue;

						curTarget = ent;
						dist = value;
					}
				}
			}

			// pbot.changeSlot(2);

			if (pbot.player.posX < xLimit) {
				if (pbot.player.posX < -222) {
					pbot.player.rotationYaw = MiscUtils.random(-125f, -52f);
					// pbot.player.rotationYaw = MiscUtils.random(-30f, 80f);
					// pbot.player.rotationYaw = 0f;
				}
				curTarget = null;

				if (runToTarget.getValue()) {
					pbot.mc.gameSettings.keyBindSprint.pressed = true;
					pbot.mc.gameSettings.keyBindForward.pressed = true;
					pbot.mc.gameSettings.keyBindJump.pressed = true;
				}
				return;
			}

			if (curTarget != null) {
				if (curTarget.posX < xLimit) {
					curTarget = null;
				} else if (curTarget.posY < pbot.player.posY - 12f) {
					curTarget = null;
				} else if (curTarget.posY > pbot.player.posY + 5f) {
					curTarget = null;
				}
			}

			if (curTarget != null) {
				dist = curTarget.getDistanceToEntity(pbot.player);
				if (runToTarget.getValue()) {
					pbot.mc.gameSettings.keyBindSprint.pressed = true;
					pbot.mc.gameSettings.keyBindForward.pressed = true;
					pbot.mc.gameSettings.keyBindJump.pressed = true;
				}
				RotationUtils.facePlayer(curTarget, silent.getValue(), pbot.player);
			} else {
				if (runToTarget.getValue()) {
					pbot.mc.gameSettings.keyBindSprint.pressed = false;
					pbot.mc.gameSettings.keyBindForward.pressed = false;
					pbot.mc.gameSettings.keyBindJump.pressed = false;
					pbot.mc.gameSettings.keyBindForward.pressed = false;
				}
			}

			if (time.hasReached(500)) {
				if (curTarget != null) {
					if (dist < 4f) {
						CombatUtils.attackEntity(curTarget, pbot);
					}
				}
				time.reset();
			}

			if (dist < 1) {
				pbot.mc.gameSettings.keyBindForward.pressed = false;
			}
		} else {
			World world = pbot.getWorld();
			if (useClientList) {
				world = Client.mc.world;
			}
			if (world == null) {
				return;
			}

			float frange = (float) range.getValue();

			if (closestMode.getValue()) {
				curTarget = CombatUtils.getClosestTarget(angle.getValue(), frange, legit.getValue(), world, pbot.player);
			} else {
				curTarget = CombatUtils.getTarget(angle.getValue(), frange, legit.getValue(), world, pbot.player);
			}
			double dist = 9999;

			if (curTarget != null) {
				dist = curTarget.getDistanceToEntity(pbot.player);
				if (runToTarget.getValue()) {
					pbot.mc.gameSettings.keyBindSprint.pressed = true;
					pbot.mc.gameSettings.keyBindForward.pressed = true;
					pbot.mc.gameSettings.keyBindJump.pressed = true;
				}
				RotationUtils.facePlayer(curTarget, silent.getValue(), pbot.player);
			} else {
				if (runToTarget.getValue()) {
					pbot.mc.gameSettings.keyBindSprint.pressed = false;
					pbot.mc.gameSettings.keyBindForward.pressed = false;
					pbot.mc.gameSettings.keyBindJump.pressed = false;
					pbot.mc.gameSettings.keyBindForward.pressed = false;
				}
			}

			if (time.hasReached(500)) {
				if (curTarget != null) {
					if (dist < 4f) {
						CombatUtils.attackEntity(curTarget, pbot);
					}
				}
				time.reset();
			}

			if (dist < 2) {
				pbot.mc.gameSettings.keyBindForward.pressed = false;
			}
		}
	}

	public static void useClientList(boolean b) {
		useClientList = b;
	}
}
