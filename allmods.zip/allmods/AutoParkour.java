package rawfish2d.client.pbot.modules;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketParticles;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import rawfish2d.client.Client;
import rawfish2d.client.modulebase.ModuleType;
import rawfish2d.client.pbot.PBot;
import rawfish2d.client.pbot.modulebase.PBotModuleBase;
import rawfish2d.client.utils.MiscUtils;
import rawfish2d.client.utils.RotationUtils;
import rawfish2d.client.utils.movement.MovementHelper;
import rawfish2d.utils.BoolValue;
import rawfish2d.utils.DoubleValue;
import rawfish2d.utils.Vector2f;
import rawfish2d.utils.Vector3f;

public class AutoParkour extends PBotModuleBase {
	private Vector3f pos = null;
	private Vector3f posNext = null;
	private int airTicks = 0;
	private int groundTicks = 0;
	private int waitTicks = 0;
	private MovementHelper mv = null;
	private float jumps = 0;
	private boolean landed = false;

	// private Vector3f parkourPos = new Vector3f();
	private boolean parkourStarted = false;
	private boolean teleported = false;

	private List<Vector3f> particlePosList = new ArrayList<Vector3f>();

	private DoubleValue maxJumps = new DoubleValue(101, 0, 500);
	private BoolValue autoFall = new BoolValue(false);
	private DoubleValue jumpDelay = new DoubleValue(5, 0, 100);

	private BoolValue debug = new BoolValue(true);

	public AutoParkour(String name, String desc, int keybind, ModuleType type, final PBot pbot) {
		super(name, desc, keybind, type, pbot);
	}

	@Override
	public void onEnable() {
		reset();

		mv = new MovementHelper(pbot);
		mv.setRotation(pbot.player);
		mv.setMotion(pbot.player);
		mv.setPos(pbot.player);
		mv.setMove(pbot.player);
	}

	@Override
	public void onDisable() {
		reset();
	}

	private void reset() {
		pos = null;
		posNext = null;
		mv = null;
		rawfish2d.client.modmovement.AutoParkour.parkourPos = null;

		airTicks = 0;
		groundTicks = 0;
		jumps = 0;
		parkourStarted = false;
		teleported = false;

		pbot.mc.gameSettings.keyBindForward.pressed = false;
		pbot.mc.gameSettings.keyBindSprint.pressed = false;
		particlePosList.clear();
	}

	@Override
	public void onPreUpdate() {
		if (rawfish2d.client.modmovement.AutoParkour.parkourPos == null) {
			if (pbot.mc.gameSettings.keyBindAttack.isKeyDown()) {
				// RayTrace checkBlockId
				RayTraceResult rt = pbot.player.rayTrace(40, Client.mc.getRenderPartialTicks());
				if (rt != null) {

					float offsetx = 0f;
					if (rt.sideHit == EnumFacing.EAST) {
						offsetx = -1f;
					}

					float offsetz = 0f;
					if (rt.sideHit == EnumFacing.SOUTH) {
						offsetz = -1f;
					}

					float offsety = -0.5f;
					if (rt.sideHit == EnumFacing.UP) {
						offsety = -1f;
					}

					if (rt.typeOfHit == Type.BLOCK) {
						float x = (float) (rt.hitVec.x + offsetx);
						float y = (float) (rt.hitVec.y + offsety);
						float z = (float) (rt.hitVec.z + offsetz);
						rawfish2d.client.modmovement.AutoParkour.parkourPos = new Vector3f(x, y, z);
					}
				}
			}
		}

		if (waitTicks > 0) {
			pbot.mc.gameSettings.keyBindSprint.pressed = false;
			pbot.mc.gameSettings.keyBindForward.pressed = false;
			waitTicks--;
		}

		if (parkourStarted) {
			doParkour();
		} else {
			// aim at "parkour starting plate"
			if (!teleported) {
				Vector2f angles = RotationUtils.getRotationFromPositionPBot(rawfish2d.client.modmovement.AutoParkour.parkourPos, pbot);
				pbot.player.rotationYaw = angles.x;
				pbot.mc.gameSettings.keyBindForward.pressed = true;
				pbot.mc.gameSettings.keyBindSprint.pressed = true;
			} else {
				float max = 0f;
				Vector3f playerPos = MiscUtils.getEntityPosF(pbot.player);
				for (Vector3f particlePos : particlePosList) {
					float dist = (float) MiscUtils.getDistance(playerPos, particlePos);
					if (dist < 6f && dist > max) {
						max = dist;
						this.posNext = particlePos;
						this.parkourStarted = true;
					}
				}
			}
		}
    }

	private void doParkour() {
		if (jumps >= maxJumps.getValue() && autoFall.getValue()) {
			pbot.mc.gameSettings.keyBindSprint.pressed = true;
			pbot.mc.gameSettings.keyBindForward.pressed = true;
			return;
		}

		mv.setRotation(pbot.player);
		mv.setMotion(pbot.player);
		mv.setPos(pbot.player);
		mv.setMove(pbot.player);
		mv.update();
		// mv.update();

		// MiscUtils.sendChatClient("============== tick:" + tick + " =================");
		// MiscUtils.sendChatClient("�aonGround: " + mv.onGround);
		// MiscUtils.sendChatClient("�aposX: " + mv.posX);
		// MiscUtils.sendChatClient("�aposY: " + mv.posY);
		// MiscUtils.sendChatClient("�aposZ: " + mv.posZ);
		// MiscUtils.sendChatClient("�emotionY: " + mv.motionY);
		// tick++;

		if (posNext == null) {
			return;
		}

		landed = pbot.player.onGround;
		if (landed) {
			pos = posNext.copy();
		}

		if (pos != null) {
			float minX = (float) Math.floor(pos.x) + 0.3f;
			float maxX = (float) Math.ceil(pos.x) - 0.3f;

			float minZ = (float) Math.floor(pos.z) + 0.3f;
			float maxZ = (float) Math.ceil(pos.z) - 0.3f;

			if (MiscUtils.getDistance(pos, MiscUtils.getEntityPosF(pbot.player)) < 100) {
				Vector2f angles = RotationUtils.getRotationFromPositionPBot(pos, pbot);
				pbot.player.rotationYaw = angles.x;
			}

			if (!mv.onGround) {
				if (pbot.player.onGround) {
					pbot.player.jump();
				}
			}

			if (pbot.player.posX >= minX && pbot.player.posX <= maxX && pbot.player.posZ >= minZ && pbot.player.posZ <= maxZ) {
				pbot.mc.gameSettings.keyBindForward.pressed = false;
				pbot.mc.gameSettings.keyBindSprint.pressed = false;
				pbot.player.motionX = 0;
				pbot.player.motionZ = 0;
			} else {
				pbot.mc.gameSettings.keyBindForward.pressed = true;
				pbot.mc.gameSettings.keyBindSprint.pressed = true;
			}
		}
	}

	@Override
	public void onRenderOverlay() {

	}

	@Override
	public void onRender() {

	}

	@Override
	public boolean onPacket(Packet packet) {
		if (packet instanceof SPacketChat) {
			SPacketChat p = (SPacketChat) packet;
			String text = p.getChatComponent().getUnformattedText();
			if (text.contains("�� ���������") || text.contains("�� �����")) {
				// toggle();
				pbot.botInfoPrint("�cParkour Failed: " + jumps + " jumps");
				particlePosList.clear();
				parkourStarted = false;
				waitTicks = 20;
				jumps = 0;
				pos = null;
				posNext = null;
				teleported = false;

				pbot.sendMessage("/spawn");
			}
		}

		if (packet instanceof SPacketPlayerPosLook) {
			SPacketPlayerPosLook p = (SPacketPlayerPosLook) packet;
			if (!this.parkourStarted && p.getY() > 80) {
				teleported = true;
				waitTicks = 20;
			}
		}

		if (packet instanceof SPacketParticles) {
			SPacketParticles p = (SPacketParticles) packet;
			EnumParticleTypes type = EnumParticleTypes.EXPLOSION_NORMAL;
			EnumParticleTypes type2 = EnumParticleTypes.CRIT;
			if (p.getParticleType() == type || p.getParticleType() == type2) {
				Vector3f partPos = new Vector3f(p.getXCoordinate(), p.getYCoordinate(), p.getZCoordinate());
				partPos.x = (float) (Math.floor(partPos.x) + 0.5f);
				partPos.y = (float) (Math.floor(partPos.y) + 0.5f);
				partPos.z = (float) (Math.floor(partPos.z) + 0.5f);

				if (!parkourStarted) {
					particlePosList.add(partPos);
				} else {
					float maxDistance = 128f;
					if (this.parkourStarted) {
						maxDistance = 6f;
					}
					if (MiscUtils.getDistance(partPos, MiscUtils.getEntityPosF(pbot.player)) < maxDistance) {
						posNext = partPos;
						Vector2f angles = RotationUtils.getRotationFromPositionPBot(posNext, pbot);
						pbot.player.rotationYaw = angles.x;
						waitTicks = (int) jumpDelay.getValue();
						jumps++;
					}
				}
			}
			// MiscUtils.sendChatClient("packet particles: " + p.getParticleType());
		}
		return true;
	}
}
