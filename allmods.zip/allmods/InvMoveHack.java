package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class InvMoveHack extends Module {
	
	public static InvMoveHack mod;
	public InvMoveHack() {
		super("InvMoveHack", Keyboard.KEY_NONE, ModuleType.Exploit);
		mod = this;
	}
	
	public void onUpdate() {
		Minecraft mc = Minecraft.getMinecraft();
		 final KeyBinding[] keys;
	     final KeyBinding[] arrkeyBinding = keys = new KeyBinding[] { mc.gameSettings.keyBindForward, mc.gameSettings.keyBindBack, mc.gameSettings.keyBindLeft, mc.gameSettings.keyBindRight, mc.gameSettings.keyBindJump, mc.gameSettings.keyBindSprint };
	     if (mc.currentScreen != null && !(mc.currentScreen instanceof GuiChat)) {
	            final KeyBinding[] arrayOfKeyBinding = keys;
	            for (int i = keys.length, b = 0; b < i; b = (byte)(b + 1)) {
	                final KeyBinding bind = arrayOfKeyBinding[b];
	                bind.pressed = Keyboard.isKeyDown(bind.getKeyCode());;
	            }
	     }
	}
}
