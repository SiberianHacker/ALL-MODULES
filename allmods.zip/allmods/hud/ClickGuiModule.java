package ru.dedinside.modules.impl.hud;

import org.lwjgl.input.Keyboard;
import ru.dedinside.Expensive;
import ru.dedinside.modules.Module;
import ru.dedinside.modules.ModuleAnnotation;
import ru.dedinside.modules.Type;
import ru.dedinside.ui.dropui.setting.imp.BooleanSetting;
import ru.dedinside.ui.dropui.setting.imp.ColorSetting;
import ru.dedinside.ui.dropui.setting.imp.SliderSetting;
import ru.dedinside.ui.newui.ClickScreen;

import java.awt.*;

@ModuleAnnotation(name = "ClickGUI", desc = "���������� ��� ����", type = Type.Hud)

public class ClickGuiModule extends Module {

    public ColorSetting color = new ColorSetting("Color", -1);
    public BooleanSetting optimize = new BooleanSetting("Optimize Gui", false);

    public ClickGuiModule() {
        bind = Keyboard.KEY_RSHIFT;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        mc.displayGuiScreen(Expensive.getInstance().menuMain);
        Expensive.getInstance().manager.getModule(ClickGuiModule.class).setState(false);

    }

    public static Color getColor() {
        return ((ClickGuiModule) Expensive.getInstance().manager.getModule(ClickGuiModule.class)).color.getColorValueColor();
    }




    public static boolean getOptimize() {
        return !((ClickGuiModule) Expensive.getInstance().manager.getModule(ClickGuiModule.class)).optimize.state;
    }
}
