package me.independed.inceptice.modules.hud;

import me.independed.inceptice.modules.Module;

public class InventoryView extends Module {
      public InventoryView() {
            super("InventoryView", "show your inventory on the screen", (1322414991 >> 1 ^ 90183130 | 83900603) >>> 4 ^ 40932299, Module.Category.HUD);
      }
}
