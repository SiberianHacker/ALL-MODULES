/*   */ package org.neverhook.client.feature.impl.hud;
/*   */ 
/*   */ import org.neverhook.client.feature.Feature;
/*   */ import org.neverhook.client.feature.impl.Type;
/*   */ 
/*   */ public class ClientSounds
/*   */   extends Feature {
/*   */   public ClientSounds() {
/* 9 */     super("ClientSounds", "Звуки при включении функции и выключении", Type.Hud);
/*   */   }
/*   */ }


/* Location:              C:\Users\Admin\OneDrive\Рабочий стол\NeverHook Crack.jar!\org\neverhook\client\feature\impl\hud\ClientSounds.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */