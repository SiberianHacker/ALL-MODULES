package me.independed.inceptice.modules.hud;

import me.independed.inceptice.modules.Module;

public class GuiParticles extends Module {
      public GuiParticles() {
            super("GuiParticles", "show particles in ClickGUI", 67354778 >> 4 ^ 4209673, Module.Category.HUD);
            this.toggle();
      }
}
