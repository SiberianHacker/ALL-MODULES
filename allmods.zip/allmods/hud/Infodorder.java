package zamorozka.modules.HUD;

import zamorozka.module.Category;
import zamorozka.module.Module;

public class Infodorder extends Module{

	public Infodorder() {
		super("InfoBoard", 0, Category.Hud);
	}
	public void onUpdate(){
		if(!getState()){
		
		}
		
	}
}
