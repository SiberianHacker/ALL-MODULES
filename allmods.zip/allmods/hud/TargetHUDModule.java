package ru.dedinside.modules.impl.hud;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.MathHelper;
import ru.dedinside.Expensive;
import ru.dedinside.event.EventTarget;
import ru.dedinside.event.events.impl.EventDisplay;
import ru.dedinside.modules.Module;
import ru.dedinside.modules.ModuleAnnotation;
import ru.dedinside.modules.Type;
import ru.dedinside.modules.impl.combat.AuraModule;
import ru.dedinside.modules.impl.player.NameProtectModule;
import ru.dedinside.ui.dropui.setting.imp.ModeSetting;
import ru.dedinside.util.animations.AnimationMath;
import ru.dedinside.util.drag.Dragging;
import ru.dedinside.util.font.Fonts;
import ru.dedinside.util.math.MathUtility;
import ru.dedinside.util.render.GlowUtility;
import ru.dedinside.util.render.RenderUtility;
import ru.dedinside.util.shader.StencilUtil;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@ModuleAnnotation(name = "TargetHUD", desc = "���������� � ����������", type = Type.Hud)
public class TargetHUDModule extends Module {
    public ModeSetting thudMode = new ModeSetting("Mode", "Type 1", "Type 1", "Type 2", "Type 3");
    public final Dragging targetHUDDrag = Expensive.getInstance().createDrag(this, "targetHUDDrag", 282, 266);

    private static EntityLivingBase curTarget = null;
    private double scale = 0;
    float hp, ar;
    int posX;
    int posY;



    @EventTarget
    public void onDispay(EventDisplay eventDisplay) {
        if (AuraModule.targetEntity == null) {
            if (mc.player != null && mc.currentScreen instanceof GuiChat) {
                curTarget = mc.player;
                scale = AnimationMath.animation((float) scale, (float) 1, (float) (3 * AnimationMath.deltaTime()));
            } else {
                scale = AnimationMath.animation((float) scale, (float) 0, (float) (3 * AnimationMath.deltaTime()));
            }
        } else {
            curTarget = AuraModule.targetEntity;
            scale = AnimationMath.animation((float) scale, (float) 1, (float) (3 * AnimationMath.deltaTime()));
        }
        if (curTarget == null || !(curTarget instanceof EntityPlayer)) {
            return;
        }
        String name = Expensive.getInstance().manager.getModule(NameProtectModule.class).state && curTarget.getName().equals(mc.player.getName())
                ? ChatFormatting.DARK_PURPLE + "expensiveclient.xyz" : Expensive.getInstance().manager.getModule(NameProtectModule.class).state
                && NameProtectModule.youtuber.get() ? ChatFormatting.RED + "expensiveclient.xyz" :
                ChatFormatting.stripFormatting(curTarget.getName());
        if (thudMode.is("Type 1")) {
            float width = 90 + Fonts.SEMI_BOLD_12.getStringWidth(name);
            float height = 30;
            targetHUDDrag.setWidth(width);
            targetHUDDrag.setHeight(height);
            posX = (int) targetHUDDrag.getX();
            posY = (int) targetHUDDrag.getY();
            hp = MathUtility.clamp(MathUtility.lerp(hp, curTarget.getHealth() / curTarget.getMaxHealth(), (float) (12 * AnimationMath.deltaTime())), 0, 1);
            GlStateManager.pushMatrix();
            Expensive.getInstance().scaleMath.pushScale();
            GlStateManager.translate(posX + width / 2, posY + 43 / 2, 0);
            GlStateManager.scale(scale, scale, 1);
            GlStateManager.translate(-posX - width / 2, -posY - 43 / 2, 0);

            GlowUtility.drawGlow(posX, posY, width, height, 10, new Color(8, 8, 8, 100));
            RenderUtility.drawRound(posX, posY, width, height, 2, new Color(8, 8, 8));
            RenderUtility.drawFace(posX + 5, posY + 4, 8, 8, 8, 8, 22, 22, 64, 64, (AbstractClientPlayer) curTarget);
            RenderUtility.drawCircle(posX + width - 15, posY + height / 2, 0, 360, 10, 3, false, new Color(55, 55, 55));
            RenderUtility.drawCircle(posX + width - 15, posY + height / 2, 0, hp * 360 + 1, 10, 3, false, HudModule.getColor((int) (hp * 360)));

            Fonts.SEMI_BOLD_12.drawString("Name: " + name, posX + 35, posY + 10, -1);
            Fonts.SEMI_BOLD_12.drawString("Distance: " + MathUtility.round(mc.player.getDistance(curTarget), 0.01f), posX + 35, posY + 18, -1);
            Fonts.SEMI_BOLD_12.drawCenteredString(MathUtility.round(hp * 20, 0.1f) + "", posX + width - 15, posY + height / 2 - 1, -1);

            if (!curTarget.getHeldItem(EnumHand.OFF_HAND).isEmpty()) {
                GlowUtility.drawGlow(posX + width + 7, posY + 5, 18, 20, 10, new Color(8, 8, 8, 100));
                RenderUtility.drawRound(posX + width + 7, posY + 5, 18, 20, 2, new Color(8, 8, 8));

                float pox = curTarget.getHeldItem(EnumHand.OFF_HAND).getItem() instanceof ItemAppleGold ? posX + width + 7 : posX + width + 9;

                GlStateManager.enableTexture2D();
                GlStateManager.depthMask(true);
                GlStateManager.clear(256);
                GlStateManager.enableDepth();
                GlStateManager.disableAlpha();
                mc.getRenderItem().zLevel = -150.0f;
                RenderHelper.enableStandardItemLighting();
                mc.getRenderItem().renderItemAndEffectIntoGUI(curTarget.getHeldItem(EnumHand.OFF_HAND), (int) (pox), posY + 6);
                mc.getRenderItem().renderItemOverlays(mc.fontRenderer, curTarget.getHeldItem(EnumHand.OFF_HAND), (int) (pox), posY + 6.5F);
                RenderHelper.disableStandardItemLighting();
                mc.getRenderItem().zLevel = 0.0f;
                GlStateManager.enableAlpha();
            }
            Expensive.getInstance().scaleMath.popScale();
            GlStateManager.popMatrix();
        }
        if (thudMode.is("Type 2")) {
            float width = 50 + Fonts.SEMI_BOLD_12.getStringWidth(name);
            float height = 30;
            targetHUDDrag.setWidth(width + 20);
            targetHUDDrag.setHeight(height);
            posX = (int) targetHUDDrag.getX();
            posY = (int) targetHUDDrag.getY();
            float x2 = posX;

            hp = MathUtility.clamp(MathUtility.lerp(hp, curTarget.getHealth() / curTarget.getMaxHealth(), (float) (12 * AnimationMath.deltaTime())), 0, 1);
            GlStateManager.pushMatrix();
            Expensive.getInstance().scaleMath.pushScale();
            GlStateManager.translate(posX + width / 2, posY + 43 / 2, 0);
            GlStateManager.scale(scale, scale, 1);
            GlStateManager.translate(-posX - width / 2, -posY - 43 / 2, 0);

            RenderUtility.drawRound(posX, posY, width + 20, 36.5f, 2, new Color(0, 0, 0, 128));

            RenderUtility.drawRect(posX + 2, posY + 2, 24, 24, Color.BLACK.getRGB());
            RenderUtility.drawFace(posX + 2, posY + 2, 8, 8, 8, 8, 24, 24, 64, 64, (AbstractClientPlayer) curTarget);

            Fonts.SEMI_BOLD_14.drawString(name, posX + 28, posY + 4, -1);
            Fonts.SEMI_BOLD_12.drawString("Health: " + MathUtility.round(hp * 20, 0.1f), posX + 28, posY + 12, -1);
            drawItemTargetHUD((EntityPlayer) curTarget, posX, posY, x2);

            RenderUtility.drawRound(posX + 2, posY + 29, width + 16, 5, 1, new Color(0, 0, 0, 64));
            RenderUtility.drawGradientHorizontal(posX + 3, posY + 30, (width + 18) * hp - 4, 3, 1, HudModule.getColor(1), new Color(88, 186, 199));
            if (!curTarget.getHeldItem(EnumHand.OFF_HAND).isEmpty()) {
                RenderUtility.drawRound(posX + width + 25, posY + 8, 18, 20, 2, new Color(0, 0, 0, 128));
                float pox = curTarget.getHeldItem(EnumHand.OFF_HAND).getItem() instanceof ItemAppleGold ? posX + width + 25 : posX + width + 27;
                GlStateManager.enableTexture2D();
                GlStateManager.depthMask(true);
                GlStateManager.clear(256);
                GlStateManager.enableDepth();
                GlStateManager.disableAlpha();
                mc.getRenderItem().zLevel = -150.0f;
                RenderHelper.enableStandardItemLighting();
                mc.getRenderItem().renderItemAndEffectIntoGUI(curTarget.getHeldItem(EnumHand.OFF_HAND), (int) pox, posY + 10);
                mc.getRenderItem().renderItemOverlays(mc.fontRenderer, curTarget.getHeldItem(EnumHand.OFF_HAND), (int) pox, posY + 10);
                RenderHelper.disableStandardItemLighting();
                mc.getRenderItem().zLevel = 0.0f;
                GlStateManager.enableAlpha();
            }
            Expensive.getInstance().scaleMath.popScale();
            GlStateManager.popMatrix();
        }
        if (thudMode.is("Type 3")) {
            float width = Math.max(Fonts.SEMI_BOLD_14.getStringWidth(name) + 50, 80);
            targetHUDDrag.setWidth(width);
            targetHUDDrag.setHeight(35.5f);

            posX = (int) targetHUDDrag.getX();
            posY = (int) targetHUDDrag.getY();

            hp = MathHelper.clamp(MathUtility.interpolate(hp, curTarget.getHealth() / curTarget.getMaxHealth(), 0.8f), 0, 1);
            ar = MathHelper.clamp(MathUtility.interpolate(ar, curTarget.getTotalArmorValue() / 20f, 0.8f), 0, 1);

            GlStateManager.pushMatrix();
            GlStateManager.translate(posX + width / 2, posY + 35.5 / 2, 0);
            GlStateManager.scale(scale, scale, 1);
            GlStateManager.translate(-posX - width / 2, -posY - 35.5 / 2, 0);
            RenderUtility.drawRect(posX, posY, width, 35.5f, new Color(0, 0, 0, 128).getRGB());

            RenderUtility.drawRect(posX + 2, posY + 2, 24, 24, Color.BLACK.getRGB());
            RenderUtility.drawFace(posX + 2, posY + 2, 8, 8, 8, 8, 24, 24, 64, 64, (AbstractClientPlayer) curTarget);

            Fonts.SEMI_BOLD_14.drawString(name, posX + 28, posY + 4, -1);
            Fonts.SEMI_BOLD_12.drawString("Health: " + MathUtility.round(curTarget.getHealth(), 0.5f), posX + 28, posY + 12, -1);
            Fonts.SEMI_BOLD_12.drawString("Distance: " + MathUtility.round(curTarget.getDistance(mc.player), 0.1f), posX + 28, posY + 20, -1);

            RenderUtility.drawRect(posX + 1.5f, posY + 28.5f, width - 3, 2.5f, new Color(0, 0, 0, 64).getRGB());
            RenderUtility.horizontalGradient(posX + 2f, posY + 29f, (width - 4f) * hp, 1.5f, new Color(0, 156, 65).getRGB(), new Color(142, 255, 193).getRGB());

            RenderUtility.drawRect(posX + 1.5f, posY + 31.5f, width - 3, 2.5f, new Color(0, 0, 0, 63).getRGB());
            RenderUtility.horizontalGradient(posX + 2f, posY + 32f, (width - 4f) * ar, 1.5f, new Color(0, 103, 176).getRGB(), new Color(57, 213, 255).getRGB());
            StencilUtil.initStencilToWrite();
            RenderUtility.drawRect(posX, posY, width, 35.5f, new Color(0, 0, 0, 128).getRGB());
            StencilUtil.readStencilBuffer(0);
            GlowUtility.drawGlow(posX, posY, width, 35.5f, 5, new Color(0, 0, 0, 128));
            StencilUtil.uninitStencilBuffer();
            GlStateManager.popMatrix();
        }
    }

    public static void drawItemTargetHUD(EntityPlayer player, float posX, float posY, float x2) {
        List<ItemStack> list = new ArrayList<>(Collections.singletonList(player.getHeldItemMainhand()));
        for (int i = 1; i < 5; ++i) {
            ItemStack getEquipmentInSlot = player.getEquipmentInSlot(i);
            list.add(getEquipmentInSlot);
        }
        for (ItemStack itemStack : list) {
            RenderHelper.enableGUIStandardItemLighting();
            GlStateManager.pushMatrix();
            GlStateManager.translate(posX, posY, 1.0f);
            GlStateManager.scale(0.6f, 0.6f, 0.6f);
            GlStateManager.translate(-posX - 5.0f, -posY + 23.0f, 1.0f);
            renderItem(itemStack, (int) x2 + 50, (int) (posY + 6));
            GlStateManager.popMatrix();
            x2 += 18.0f;
        }
    }

    public static void renderItem(ItemStack itemStack, int x, int y) {
        GlStateManager.enableTexture2D();
        GlStateManager.depthMask(true);
        GlStateManager.clear(256);
        GlStateManager.enableDepth();
        GlStateManager.disableAlpha();
        mc.getRenderItem().zLevel = -150.0f;
        RenderHelper.enableStandardItemLighting();
        mc.getRenderItem().renderItemAndEffectIntoGUI(itemStack, x, y);
        mc.getRenderItem().renderItemOverlays(mc.fontRenderer, itemStack, x, y);
        RenderHelper.disableStandardItemLighting();
        mc.getRenderItem().zLevel = 0.0f;
        GlStateManager.enableAlpha();
    }
}
