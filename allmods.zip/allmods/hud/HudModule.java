package ru.dedinside.modules.impl.hud;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.ThreadDownloadImageData;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.texture.SimpleTexture;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.opengl.GL11;
import ru.dedinside.Expensive;
import ru.dedinside.event.EventTarget;
import ru.dedinside.event.events.impl.EventDisplay;
import ru.dedinside.modules.Module;
import ru.dedinside.modules.ModuleAnnotation;
import ru.dedinside.modules.Type;
import ru.dedinside.ui.dropui.setting.imp.ColorSetting;
import ru.dedinside.ui.dropui.setting.imp.ModeSetting;
import ru.dedinside.ui.dropui.setting.imp.MultiBoxSetting;
import ru.dedinside.ui.dropui.setting.imp.SliderSetting;
import ru.dedinside.ui.newui.SmartScissor;
import ru.dedinside.util.animations.AnimationMath;
import ru.dedinside.util.animations.Translate;
import ru.dedinside.util.color.ColorUtility;
import ru.dedinside.util.drag.Dragging;
import ru.dedinside.util.font.FontRenderer;
import ru.dedinside.util.font.Fonts;
import ru.dedinside.util.math.MathUtility;
import ru.dedinside.util.render.GlowUtility;
import ru.dedinside.util.render.RenderUtility;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("all")
@ModuleAnnotation(name = "Hud", desc = "���������� ���������� � ����", type = Type.Hud)
public class HudModule extends Module {
    float upanimation = 0;
    public static MultiBoxSetting hudElements = new MultiBoxSetting("Elements", new String[]{"Watermark", "Coords Info", "BPS Info", "FPS Info", "ArrayList", "Timer Indicator", "Potion Status", "ArmorHUD"});
    public static ModeSetting fontMode = new ModeSetting("Font Mode", "GreyCliff", "GreyCliff", "Rubik", "SF Pro");
    public static ModeSetting colorMode = new ModeSetting("Client Color", "Static", () -> hudElements.get(4), "Astolfo", "Rainbow", "Fade", "Static");
    static MultiBoxSetting arrayListElements = new MultiBoxSetting("List Elements", new String[]{"Shadow", "Glow", "Lower Case", "Right Line", "RightLine Glow"}, () -> hudElements.get(4));
    static MultiBoxSetting arrayListLimitations = new MultiBoxSetting("List Limitations", new String[]{"Hide Render", "Only Bounds"}, () -> hudElements.get(4));

    public static ColorSetting onecolor = new ColorSetting("Color", new Color(245, 123, 245).getRGB(),
            () -> colorMode.currentMode.equals("Fade") && hudElements.get(4) || colorMode.currentMode.equals("Two Color")
                    && hudElements.get(4) || colorMode.currentMode.equals("Static") && hudElements.get(4));
    public static ColorSetting twoColor = new ColorSetting("Two Color", new Color(51, 50, 50).getRGB(),
            () -> colorMode.currentMode.equals("Two Color") && hudElements.get(4));
    public static SliderSetting speed = new SliderSetting("Color Speed", 5, 1, 9.9f, 1, () -> hudElements.get(4));

    Dragging arrayDrag = Expensive.getInstance().createDrag(this, "arrayList", 5, 10);
    public final Dragging timerDrag = Expensive.getInstance().createDrag(this, "timerDrag", 441, 8);
    public Dragging drag = Expensive.getInstance().createDrag(this, "Potion Status", 3, 25);
    public float offset = 0;


    public FontRenderer getFont() {
        FontRenderer font = Fonts.GREYCLIFF_18;
        String mode = fontMode.getOptions();
        switch (mode) {
            case "GrayCliff":
                font = Fonts.GREYCLIFF_18;
                break;
            case "Rubik":
                font = Fonts.RUBIK_14;
                break;
            case "SF Pro":
                font = Fonts.SEMI_BOLD_14;
                break;
        }
        return font;
    }

    @EventTarget
    public void render(EventDisplay e) {
        if (hudElements.get(0) && !mc.gameSettings.showDebugInfo) {
            GL11.glEnable(GL11.GL_ALPHA_TEST);
            GL11.glEnable(GL11.GL_BLEND);
            float width = Fonts.SEMI_BOLD_12.getStringWidth("expenisve" + "   " + Expensive.getInstance().data.getName() + "   " +
                    mc.getDebugFPS() + " fps");
            // shadow
            GlowUtility.drawGlow(3, 4, width + 6, 25 / 2f, 15, new Color(10, 10, 10, 200));

            // background
            RenderUtility.drawRound(3, 4, width + 6, 25 / 2f, 2, new Color(8, 8, 8));

            //text
            Fonts.SEMI_BOLD_12.drawString("expensive" + ChatFormatting.DARK_GRAY + " | "
                    + ChatFormatting.RESET + Expensive.getInstance().data.getName() + ChatFormatting.DARK_GRAY + " | " +
                    ChatFormatting.RESET + mc.getDebugFPS() + " fps", 6, 9, -1);

        }
        double blockpersecord = Math.hypot(mc.player.prevPosX - mc.player.posX, mc.player.prevPosZ - mc.player.posZ) * 20;

        int height = Expensive.getInstance().scaleMath.calc(e.sr.getScaledHeight());
        upanimation = AnimationMath.animation(upanimation, (float) (mc.currentScreen instanceof GuiChat ? height - 22
                : height - 9), (float) (6 * AnimationMath.deltaTime()));
        String widthCoords = "Coords:  " + mc.player.getPosition().getX() + ", " + mc.player.getPosition().getY() + ", "
                + mc.player.getPosition().getZ();
        String widthFPS = "FPS:  " + mc.getDebugFPS();
        String widthBPS = "BPS:  " + MathUtility.round(blockpersecord, 0.01f);

        if (hudElements.get(1) && !mc.gameSettings.showDebugInfo) {
            // shadow
            GlowUtility.drawGlow(3, upanimation - 6, Fonts.SEMI_BOLD_12.getStringWidth(widthCoords + 10),
                    12, 15, new Color(10, 10, 10, 200));
            // background
            RenderUtility.drawRound(3, upanimation - 6, Fonts.SEMI_BOLD_12.getStringWidth(widthCoords + 10),
                    12, 2, new Color(8, 8, 8));
            // text
            Fonts.SEMI_BOLD_12.drawStringWithShadow("Coords: " + TextFormatting.WHITE +
                    Math.round(mc.player.posX) + ", " + Math.round(mc.player.posY) + ", " +
                    Math.round(mc.player.posZ), 7, (int) upanimation - 1, -1);
        }
        if (hudElements.get(2) && !mc.gameSettings.showDebugInfo) {
            // shadow
            GlowUtility.drawGlow(hudElements.get(1) ? Fonts.SEMI_BOLD_12.getStringWidth(widthCoords + 10) +
                            11 : 3,
                    upanimation - 6, Fonts.SEMI_BOLD_12.getStringWidth(widthBPS + 10), 12, 15,
                    new Color(10, 10, 10, 200));
            // background
            RenderUtility.drawRound(hudElements.get(1) ? Fonts.SEMI_BOLD_12.getStringWidth(widthCoords + 10) +
                            11 : 3,
                    upanimation - 6, Fonts.SEMI_BOLD_12.getStringWidth(widthBPS + 10), 12, 2,
                    new Color(8, 8, 8));
            //text
            Fonts.SEMI_BOLD_12.drawStringWithShadow("BPS: " + MathUtility.round(blockpersecord, 0.01f),
                    hudElements.get(1) ? Fonts.SEMI_BOLD_12.getStringWidth(widthCoords + 10) + 11 + 4 : 7,
                    (int) upanimation - 1, -1);
        }
        if (hudElements.get(3) && !mc.gameSettings.showDebugInfo) {
            float x = 3;
            if (hudElements.get(1) && !hudElements.get(2)) {
                x = Fonts.SEMI_BOLD_12.getStringWidth(widthCoords + 10) + 11;
            }
            if (hudElements.get(2) && hudElements.get(1)) {
                x = Fonts.SEMI_BOLD_12.getStringWidth(widthCoords + widthBPS + 10) + 25f;
            }
            if (hudElements.get(2) && !hudElements.get(1)) {
                x = Fonts.SEMI_BOLD_12.getStringWidth(widthBPS + 10) + 11;
            }
            // shadow
            GlowUtility.drawGlow(x,
                    upanimation - 6, Fonts.SEMI_BOLD_12.getStringWidth(widthFPS + 10), 12, 15,
                    new Color(10, 10, 10, 200));
            // background
            RenderUtility.drawRound(x,
                    upanimation - 6, Fonts.SEMI_BOLD_12.getStringWidth(widthFPS + 10), 12, 2,
                    new Color(8, 8, 8));
            //text
            Fonts.SEMI_BOLD_12.drawCenteredStringWithShadow("FPS: " + mc.getDebugFPS()
                    , x + Fonts.SEMI_BOLD_12.getStringWidth(widthFPS + 10) / 2,
                    (int) upanimation - 1, -1);
        }

        if (hudElements.get(4) && !mc.gameSettings.showDebugInfo) {
            if (mc.gameSettings.showDebugInfo) {
                return;
            }
            ScaledResolution rs = new ScaledResolution(mc);
            List<Module> activeModules = Expensive.instance.manager.getModules();
            activeModules.sort((f1, f2) -> getFont().getStringWidth(arrayListElements.get(2) ? f1.name.toLowerCase() : f1.name) > getFont().getStringWidth(arrayListElements.get(2) ? f2.name.toLowerCase() : f2.name) ? -1 : 1);
            int count = 0;
            Expensive.getInstance().scaleMath.pushScale();

            for (Module m : activeModules) {
                if (arrayListLimitations.get(0) && m.category == Type.Visuals ||
                        arrayListLimitations.get(1) && m.bind == 0) continue;
                float width = Expensive.getInstance().scaleMath.calc(rs.getScaledWidth()) - getFont().getStringWidth(arrayListElements.get(2) ? m.name.toLowerCase() : m.name) - 3;
                Translate translate = m.translate;
                final int offset = (count * (getFont().getFontHeight() + 4));
                translate.interpolate(m.state ? width : Expensive.getInstance().scaleMath.calc(rs.getScaledWidth()) + 3d, offset, (50 / 5) * AnimationMath.deltaTime());
                if (m.state && translate.getX() <= Expensive.getInstance().scaleMath.calc(rs.getScaledWidth() + 3)) {
                    m.isRender = true;
                }
                if (translate.getX() >= Expensive.getInstance().scaleMath.calc(rs.getScaledWidth()) + 3) {
                    m.isRender = false;
                }

                if (m.isRender) {
                    GL11.glPushMatrix();
                    GL11.glTranslated(-2 - (arrayListElements.get(3) ? 1 : 0), 2, 0);
                    if (arrayListElements.get(0))
                        GlowUtility.drawGlow((float) translate.getX(), (float) translate.getY(), (float) (width - Expensive.getInstance().scaleMath.calc(rs.getScaledWidth()) + getFont().getStringWidth(arrayListElements.get(2) ? m.name.toLowerCase() : m.name) * 2 + 6), fontMode.is("GreyCliff") ? 11 : 9, 15, new Color(10, 10, 10, 200));
                    GL11.glPopMatrix();
                    count++;
                }
            }
            count = 0;
            for (Module m : activeModules) {
                if (arrayListLimitations.get(0) && m.category == Type.Visuals ||
                        arrayListLimitations.get(1) && m.bind == 0) continue;
                float width = Expensive.getInstance().scaleMath.calc(rs.getScaledWidth()) - getFont().getStringWidth(arrayListElements.get(2) ? m.name.toLowerCase() : m.name) - 3;
                Translate translate = m.translate;
                if (m.isRender) {
                    int color = getArrayColor(count);
                    GL11.glPushMatrix();
                    GL11.glTranslated(-2 - (arrayListElements.get(3) ? 1 : 0), 2, 0);
                    RenderUtility.drawRect((float) translate.getX(), (float) translate.getY(), width - Expensive.getInstance().scaleMath.calc(rs.getScaledWidth()) + getFont().getStringWidth(arrayListElements.get(2) ? m.name.toLowerCase() : m.name) * 2 + 6, fontMode.is("GreyCliff") ? 11 : 9, new Color(10, 10, 10, 150).getRGB());

                    if (arrayListElements.get(3))
                        RenderUtility.drawRect((float) translate.getX() - width + Expensive.getInstance().scaleMath.calc(rs.getScaledWidth()), (float) translate.getY(), 1, fontMode.is("GreyCliff") ? 11 : 9, color);
                    getFont().drawString(arrayListElements.get(2) ? m.name.toLowerCase() : m.name, (float) translate.getX() + 1.5f, (float) translate.getY() + 2 - 0, color);
                    GL11.glPopMatrix();

                    count++;
                }
            }

            count = 0;

            for (Module m : activeModules) {
                if (arrayListLimitations.get(0) && m.category == Type.Visuals ||
                        arrayListLimitations.get(1) && m.bind == 0) continue;
                float width = Expensive.getInstance().scaleMath.calc(rs.getScaledWidth()) - getFont().getStringWidth(arrayListElements.get(2) ? m.name.toLowerCase() : m.name) - 3;
                Translate translate = m.translate;
                if (m.isRender) {
                    int color = getArrayColor(count);
                    GL11.glPushMatrix();
                    GL11.glTranslated(-2 - (arrayListElements.get(3) ? 1 : 0), 2, 0);
                    if (arrayListElements.get(3) && arrayListElements.get(4))
                        GlowUtility.drawGlow(Math.round((float) translate.getX() - width + Expensive.getInstance().scaleMath.calc(rs.getScaledWidth())), Math.round((float) translate.getY()), 3F, fontMode.is("GreyCliff") ? 11 : 9, 15, new Color(new Color(color).getRed(), new Color(color).getGreen(), new Color(color).getBlue(), (int) 255));
                    if (arrayListElements.get(1)) {
                        GlowUtility.drawGlow(Math.round((float) translate.getX()), Math.round((float) translate.getY()) - 0.5f, (float) (width - Expensive.getInstance().scaleMath.calc(rs.getScaledWidth()) + getFont().getStringWidth(arrayListElements.get(2) ? m.name.toLowerCase() : m.name) * 2 + 6), fontMode.is("GreyCliff") ? 11 : 9, (int) 15, new Color(new Color(color).getRed(), new Color(color).getGreen(), new Color(color).getBlue(), (int) 100));
                    }
                    GL11.glPopMatrix();
                    count++;
                }
            }
            Expensive.getInstance().scaleMath.popScale();
        }
        if (hudElements.get(6) && !mc.gameSettings.showDebugInfo) {
            float width = 100;
            float height2 = 10;

            float x = drag.getX();
            float y = drag.getY();

            for (PotionEffect effect : mc.player.getActivePotionEffects()) {
                height2 += 15;
            }
            drag.setWidth(width);
            drag.setHeight(height2);
            offset = AnimationMath.fast(offset, height2, 15f);
            GlowUtility.drawGlow(x, y, width, offset, 15, new Color(25, 25, 25, 255));
            SmartScissor.push();
            SmartScissor.setFromComponentCoordinates((int) x - 3, (int) y - 3, (int) width + 6, (int) offset + 6);
            RenderUtility.drawRound(x, y, width, offset, 2, new Color(25, 25, 25, 255));
            Fonts.SEMI_BOLD_14.drawCenteredString("Potion Status", x + width / 2, y + 3, new Color(255, 255, 255, 155).getRGB());

            if (height2 > 10) {
                RenderUtility.verticalGradient(x, y + 10, width, 5, new Color(0, 0, 0, 50).getRGB(), new Color(0, 0, 0, 0).getRGB());
                int offset = 0;
                for (PotionEffect effect : mc.player.getActivePotionEffects()) {

                    Fonts.SEMI_BOLD_12.drawString(I18n.format(effect.getEffectName()) + " " + getPotionAmplifer(effect), x + 5, y + 16 + offset, new Color(255, 255, 255, 255).getRGB());

                    Fonts.SEMI_BOLD_12.drawString(getPotionTime(effect), x + width - Fonts.RUBIK_14.getStringWidth(getPotionTime(effect)) - 5, y + 15 + offset, new Color(255, 255, 255, 100).getRGB());

                    offset += 15;
                    height2 += 15;
                }
            }
            SmartScissor.unset();
            SmartScissor.pop();
        }
        if (hudElements.get(7) && !mc.gameSettings.showDebugInfo) {
            GL11.glColor4f(1, 1, 1, 1);
            ScaledResolution res = e.sr;

            final List<ItemStack> armor = new ArrayList<>();
            mc.entityRenderer.setupOverlayRendering();
            res = new ScaledResolution(mc);
            mc.player.getArmorInventoryList().forEach(armor::add);
            GL11.glPushMatrix();
            if (mc.player.getAir() < 300) {
                GL11.glTranslatef(0, -8, 0);
            }
            if (!armor.isEmpty())
                for (int i = 0; i < 4; i++) {
                    ItemStack stack = armor.get(i);
                    if (!(stack.getItem() instanceof ItemAir)) {
                        String str = String.valueOf(stack.getMaxDamage() - stack.getItemDamage());
                        Fonts.SEMI_BOLD_16.drawString(str,
                                res.getScaledWidth() / 2 - Fonts.SEMI_BOLD_16.getStringWidth(str) / 2 + 18 + i * 22,
                                res.getScaledHeight() - 62, ColorUtility.rgba(200, 200, 200, 255));
                        RenderHelper.enableGUIStandardItemLighting();
                        drawItemStack(stack, res.getScaledWidth() / 2 + 10 + i * 22, res.getScaledHeight() - 55);
                        RenderHelper.disableStandardItemLighting();
                    }
                }
            GL11.glPopMatrix();
            mc.entityRenderer.setupOverlayRendering();
        }
    }

    private void drawItemStack(ItemStack stack, double x, double y) {
        GL11.glPushMatrix();
        GL11.glTranslated(x, y, 0);
        mc.getRenderItem().renderItemAndEffectIntoGUI(stack, 0, 0);
        mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, stack, 0, 0, null);
        GL11.glPopMatrix();
    }

    public static Color getColor(int index) {
        String mode = colorMode.getOptions();

        if (mode.equalsIgnoreCase("Static")) {
            return new Color(onecolor.getColorValue());
        } else if (mode.equalsIgnoreCase("Fade")) {
            return new Color(ColorUtility.fade(5, index * 2, onecolor.getColorValueColor(), 1).getRGB());
        } else if (mode.equalsIgnoreCase("Astolfo")) {
            return astolfo(1, index * 2, 0.5f, 10 - speed.getFloatValue());
        } else if (mode.equalsIgnoreCase("Rainbow")) {
            return ColorUtility.rainbow((int) (10 - speed.getFloatValue()), index * 2, 0.5f, 1, 1);
        }
        return Color.WHITE;
    }

    public String getPotionTime(PotionEffect effect) {
        int duration = effect.getDuration();
        int seconds = duration / 20;
        int minutes = seconds / 60;
        seconds %= 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    public String getPotionAmplifer(PotionEffect e) {

        if (e.getAmplifier() == 1) {
            return "II";
        } else if (e.getAmplifier() == 2) {
            return "III";
        } else if (e.getAmplifier() == 3) {
            return "IV";
        } else if (e.getAmplifier() == 4) {
            return "V";
        } else if (e.getAmplifier() == 5) {
            return "VI";
        } else if (e.getAmplifier() == 6) {
            return "VII";
        } else if (e.getAmplifier() == 7) {
            return "VIII";
        } else if (e.getAmplifier() == 8) {
            return "IX";
        } else if (e.getAmplifier() == 9) {
            return "X";
        } else {
            return "";
        }
    }

    public int getArrayColor(int index) {
        String mode = colorMode.getOptions();
        if (mode.equalsIgnoreCase("Fade"))
            return ColorUtility.fade(10 - (int) speed.getFloatValue(), index * 20, new Color(onecolor.getColorValue()), 1).getRGB();
        if (mode.equalsIgnoreCase("Rainbow"))
            return ColorUtility.rainbow(10 - (int) speed.getFloatValue(), index * 40, 0.7f, 1, 1).getRGB();
        if (mode.equalsIgnoreCase("Astolfo")) return astolfo(1, index * 25, 0.5f, 10 - speed.getFloatValue()).getRGB();
        if (mode.equalsIgnoreCase("Static")) return onecolor.getColorValue();
        if (mode.equalsIgnoreCase("White-Color"))
            return ColorUtility.TwoColorEffect(onecolor.getColorValueColor(), new Color(255, 255, 255), Math.abs((double) System.currentTimeMillis() / 12) / 100.0 + 3.0 * ((double) index) / 60.0).getRGB();

        return -1;
    }

    public static BufferedImage parseBufferedImage(ITextureObject ito) throws Exception {
        if (ito instanceof ThreadDownloadImageData) {
            BufferedImage bi = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
            ThreadDownloadImageData t = (ThreadDownloadImageData) ito;
            return t.imageBuffer.cache();
        }
        if (ito instanceof SimpleTexture) {
            SimpleTexture st = (SimpleTexture) ito;
            return TextureUtil.readBufferedImage(mc.renderEngine.resourceManager.getResource(st.textureLocation).getInputStream());
        }
        return null;
    }


    public static Color astolfo(float yDist, float yTotal, float saturation, float speedt) {
        float speed = 1800f;
        float hue = (System.currentTimeMillis() % (int) speed) + (yTotal - yDist) * speedt;
        while (hue > speed) {
            hue -= speed;
        }
        hue /= speed;
        if (hue > 0.5) {
            hue = 0.5F - (hue - 0.5f);
        }
        hue += 0.5F;
        return Color.getHSBColor(hue, saturation, 1F);
    }
}
