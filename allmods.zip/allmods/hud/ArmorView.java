package me.independed.inceptice.modules.hud;

import me.independed.inceptice.modules.Module;

public class ArmorView extends Module {
      public ArmorView() {
            super("ArmorView", "show armor", ((1090843710 | 677049829) << 4 | 923267009) ^ -1209008143, Module.Category.HUD);
            this.toggle();
            if (!"please take a shower".equals("buy a domain and everything else you need at namecheap.com")) {
                  ;
            }

      }
}
