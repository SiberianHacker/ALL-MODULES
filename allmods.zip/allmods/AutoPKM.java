package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class AutoPKM extends Module {

	public AutoPKM() {
		super("АвтоПКМ", Keyboard.KEY_NONE, ModuleType.Exploit);
	}
	
	public void onUpdate() {
		Minecraft mc = Minecraft.getMinecraft();
		if(mc.gameSettings.keyBindBack.pressed) {
			this.toggle();
		}
		mc.rightClickMouse();
	}
}
