package rawfish2d.client.pbot.modules;

import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketChat;
import rawfish2d.client.modulebase.ModuleType;
import rawfish2d.client.pbot.PBot;
import rawfish2d.client.pbot.modulebase.PBotModuleBase;
import rawfish2d.client.utils.MiscUtils;

public class AutoChat extends PBotModuleBase {

	public AutoChat(String name, String desc, int keybind, ModuleType type, final PBot pbot) {
		super(name, desc, keybind, type, pbot);
	}

	@Override
	public void onEnable() {
	}

	@Override
	public void onDisable() {
	}

	@Override
	public boolean onPacket(Packet packet) {
		if (packet instanceof SPacketChat) {
			SPacketChat pchat = (SPacketChat) packet;

			String chatText = MiscUtils.removeFormatting(pchat.getChatComponent().getFormattedText());
			String chatTextLower = chatText.toLowerCase();

			if ((chatTextLower.contains("chat") && chatTextLower.contains("game")) || //
					chatTextLower.contains("chatgame") || //
					chatTextLower.contains("��� ����") || //
					chatTextLower.contains("�������") || //
					chatTextLower.contains("������") || //
					chatTextLower.contains("������") || //
					chatTextLower.contains("������ ������")) {

				chatText = chatText.replace("  ", " ");
				String[] split = chatText.split(" ");
				if (split.length < 3) {
					return true;
				}

				boolean hasLeft = false;
				boolean hasOp = false;
				boolean hasRight = false;

				int numLeft = 0;
				int numRight = 0;
				String operationStr = null;
				for (String str : split) {
					if (str.length() < 1) {
						continue;
					}
					if (rawfish2d.client.modmisc.AutoChat.isNumber(str)) {
						if (!hasLeft) {
							numLeft = MiscUtils.getIntValue(str);
							hasLeft = true;
							continue;
						}
						if (!hasRight) {
							numRight = MiscUtils.getIntValue(str);
							hasRight = true;
							continue;
						}
					} else if (str.equals("+") || //
							str.equals("-") || //
							str.equals("*") || //
							str.equals("/") || //
							str.equals("\\")) {
						operationStr = str;
						hasOp = true;
						continue;
					}
				}

				int result = 0;
				if (hasLeft && hasOp && hasRight) {
					if (operationStr.equals("+")) {
						result = numLeft + numRight;
					} else if (operationStr.equals("-")) {
						result = numLeft - numRight;
					} else if (operationStr.equals("*")) {
						result = numLeft * numRight;
					} else if (operationStr.equals("/") || operationStr.equals("\\")) {
						result = numLeft / numRight;
					}
					pbot.sendMessage(String.valueOf(result));
				}
			}
		}
		return true;
	}
}
