package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;

import net.minecraft.block.Block;
import net.minecraft.block.BlockShulkerBox;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class InvShulkerBox extends Module {

	public InvShulkerBox() {
		super("ShulkerViewer", Keyboard.KEY_NONE, ModuleType.Render);
		// TODO Auto-generated constructor stub
	}
	
	public void onEnable() {
		this.toolTipCancelled = true;
	}
	
	public void onDisable() {
		this.toolTipCancelled = false;
	}
	
	public void onRender2D() {
		  if (this.isEnabled()) {
	            final ScaledResolution sr = new ScaledResolution(this.mc);
	            if (this.mc.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK) {
	                final BlockPos blockpos = this.mc.objectMouseOver.getBlockPos();
	                final IBlockState iblockstate = this.mc.world.getBlockState(blockpos);
	                final Block block = iblockstate.getBlock();
	                if (iblockstate.getMaterial() == Material.AIR) {
	                    return;
	                }
	                if (block instanceof BlockShulkerBox) {
	                    final ItemStack itemstack = block.getItem((World)this.mc.world, blockpos, iblockstate);
	                    itemstack.getTagCompound();
	                }
	            }
	        }
	    }
	    
	    public void onTT() {
	        if (this.mc.player == null) {
	            return;
	        }
	        if(this.toolTipItemStack != null)
	        if (this.toolTipItemStack.getItem() instanceof ItemShulkerBox) {
	            final NBTTagCompound tagCompound = this.toolTipItemStack.getTagCompound();
	            if (tagCompound != null && tagCompound.hasKey("BlockEntityTag", 10)) {
	                final NBTTagCompound blockEntityTag = tagCompound.getCompoundTag("BlockEntityTag");
	                if (blockEntityTag.hasKey("Items", 9)) {
	                    
	                    final NonNullList<ItemStack> nonnulllist = (NonNullList<ItemStack>)NonNullList.func_191197_a(27, ItemStack.field_190927_a);
	                    ItemStackHelper.func_191283_b(blockEntityTag, (NonNullList)nonnulllist);
	                    GlStateManager.enableBlend();
	                    GlStateManager.disableRescaleNormal();
	                    RenderHelper.disableStandardItemLighting();
	                    GlStateManager.disableLighting();
	                    GlStateManager.disableDepth();
	                    final int width = Math.max(144, Minecraft.getMinecraft().fontRendererObj.getStringWidth(this.toolTipItemStack.getDisplayName()) + 3);
	                    final int x1 = this.toolTipX + 12;
	                    final int y1 = this.toolTipY - 12;
	                    final int height = 57;
	                    Minecraft.getMinecraft().getRenderItem().zLevel = 300.0f;
	                    this.drawGradientRectP(x1 - 3, y1 - 4, x1 + width + 3, y1 - 3, -267386864, -267386864);
	                    this.drawGradientRectP(x1 - 3, y1 + 57 + 3, x1 + width + 3, y1 + 57 + 4, -267386864, -267386864);
	                    this.drawGradientRectP(x1 - 3, y1 - 3, x1 + width + 3, y1 + 57 + 3, -267386864, -267386864);
	                    this.drawGradientRectP(x1 - 4, y1 - 3, x1 - 3, y1 + 57 + 3, -267386864, -267386864);
	                    this.drawGradientRectP(x1 + width + 3, y1 - 3, x1 + width + 4, y1 + 57 + 3, -267386864, -267386864);
	                    this.drawGradientRectP(x1 - 3, y1 - 3 + 1, x1 - 3 + 1, y1 + 57 + 3 - 1, 1347420415, 1344798847);
	                    this.drawGradientRectP(x1 + width + 2, y1 - 3 + 1, x1 + width + 3, y1 + 57 + 3 - 1, 1347420415, 1344798847);
	                    this.drawGradientRectP(x1 - 3, y1 - 3, x1 + width + 3, y1 - 3 + 1, 1347420415, 1347420415);
	                    this.drawGradientRectP(x1 - 3, y1 + 57 + 2, x1 + width + 3, y1 + 57 + 3, 1344798847, 1344798847);
	                    Minecraft.getMinecraft().fontRendererObj.drawString(this.toolTipItemStack.getDisplayName(), this.toolTipX + 12, this.toolTipY - 12, 16777215);
	                    GlStateManager.enableBlend();
	                    GlStateManager.enableAlpha();
	                    GlStateManager.enableTexture2D();
	                    GlStateManager.enableLighting();
	                    GlStateManager.enableDepth();
	                    RenderHelper.enableGUIStandardItemLighting();
	                    for (int i = 0; i < nonnulllist.size(); ++i) {
	                        final int iX = this.toolTipX + i % 9 * 16 + 11;
	                        final int iY = this.toolTipY + i / 9 * 16 - 11 + 8;
	                        final ItemStack itemStack = (ItemStack)nonnulllist.get(i);
	                        Minecraft.getMinecraft().getRenderItem().renderItemAndEffectIntoGUI(itemStack, iX, iY);
	                        Minecraft.getMinecraft().getRenderItem().renderItemOverlayIntoGUI(Minecraft.getMinecraft().fontRendererObj, itemStack, iX, iY, (String)null);
	                    }
	                    RenderHelper.disableStandardItemLighting();
	                    Minecraft.getMinecraft().getRenderItem().zLevel = 0.0f;
	                    GlStateManager.enableLighting();
	                    GlStateManager.enableDepth();
	                    RenderHelper.enableStandardItemLighting();
	                    GlStateManager.enableRescaleNormal();
	                }
	            }
	        }
	    }
	    
	    private void drawGradientRectP(final int left, final int top, final int right, final int bottom, final int startColor, final int endColor) {
	        final float f = (startColor >> 24 & 0xFF) / 255.0f;
	        final float f2 = (startColor >> 16 & 0xFF) / 255.0f;
	        final float f3 = (startColor >> 8 & 0xFF) / 255.0f;
	        final float f4 = (startColor & 0xFF) / 255.0f;
	        final float f5 = (endColor >> 24 & 0xFF) / 255.0f;
	        final float f6 = (endColor >> 16 & 0xFF) / 255.0f;
	        final float f7 = (endColor >> 8 & 0xFF) / 255.0f;
	        final float f8 = (endColor & 0xFF) / 255.0f;
	        GlStateManager.disableTexture2D();
	        GlStateManager.enableBlend();
	        GlStateManager.disableAlpha();
	        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
	        GlStateManager.shadeModel(7425);
	        final Tessellator tessellator = Tessellator.getInstance();
	        final BufferBuilder bufferbuilder = tessellator.getBuffer();
	        bufferbuilder.begin(7, DefaultVertexFormats.POSITION_COLOR);
	        bufferbuilder.pos((double)right, (double)top, 300.0).color(f2, f3, f4, f).endVertex();
	        bufferbuilder.pos((double)left, (double)top, 300.0).color(f2, f3, f4, f).endVertex();
	        bufferbuilder.pos((double)left, (double)bottom, 300.0).color(f6, f7, f8, f5).endVertex();
	        bufferbuilder.pos((double)right, (double)bottom, 300.0).color(f6, f7, f8, f5).endVertex();
	        tessellator.draw();
	        GlStateManager.shadeModel(7424);
	        GlStateManager.disableBlend();
	        GlStateManager.enableAlpha();
	        GlStateManager.enableTexture2D();
	    }
	}


	
	

