package ru.ShwepsikGG.Cleent.Modules;
import org.lwjgl.input.Keyboard;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemStack;
import ru.ShwepsikGG.Cleent.HeroGui.Setting;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class BadAutoGapple extends Module {
	private boolean eating;
	
	public BadAutoGapple() {
		super("AutoGapple", Keyboard.KEY_NONE, ModuleType.Player);
	      this.eating = false;
	}
	
	public void onUpdate() {
	if (Minecraft.getMinecraft().player.getHealth() + Minecraft.getMinecraft().player.getAbsorptionAmount() > 6 && this.eating) {
	    this.eating = false;
	    this.stop();
	    return;
	}
	if (!this.canEat()) {
	    return;
	}
	if (this.isFood(Minecraft.getMinecraft().player.getHeldItemOffhand()) && Minecraft.getMinecraft().player.getHealth() <= 6 && this.canEat()) {
	    KeyBinding.setKeyBindState(this.mc.gameSettings.keyBindUseItem.getKeyCode(), true);
	    this.eating = true;
	}
	if (!this.canEat()) {
	    this.stop();
	}
	    }
	    
	    public static boolean isNullOrEmptyStack(final ItemStack itemStack) {
	        return itemStack == null || itemStack.func_190926_b();
	    }
	    
	    boolean isFood(final ItemStack itemStack) {
	        return !isNullOrEmptyStack(itemStack) && itemStack.getItem() instanceof ItemAppleGold;
	    }
	    
	    public boolean canEat() {
	        return this.mc.objectMouseOver == null || !(this.mc.objectMouseOver.entityHit instanceof EntityVillager);
	    }
	    
	    void stop() {
	        KeyBinding.setKeyBindState(this.mc.gameSettings.keyBindUseItem.getKeyCode(), false);
	    }
	
	
}
