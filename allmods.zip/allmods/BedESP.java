package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBed;
import net.minecraft.util.math.AxisAlignedBB;
import ru.ShwepsikGG.Cleent.HeroGui.util.RenderUtils;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class BedESP extends Module {

	public BedESP() {
		super("BedESP", Keyboard.KEY_NONE, ModuleType.Render);
	}
	
	public void onRender3D() {
	    final Minecraft mc = Minecraft.getMinecraft();
        for (final Object o : mc.world.loadedTileEntityList) {
            final TileEntity tileEntity = (TileEntity)o;
            final double n = tileEntity.getPos().getX();
            mc.getRenderManager();
            final double x = n - RenderManager.renderPosX;
            final double n2 = tileEntity.getPos().getY();
            mc.getRenderManager();
            final double y = n2 - RenderManager.renderPosY;
            final double n3 = tileEntity.getPos().getZ();
            mc.getRenderManager();
            final double z = n3 - RenderManager.renderPosZ;
            if (tileEntity instanceof TileEntityBed) {
                RenderUtils.drawBoundingBoxESP(new AxisAlignedBB(x, y, z, x + 1.0, y + 0.6, z + 1.0), 3.5f, 1163488753);
                RenderUtils.drawFilledBBESP(new AxisAlignedBB(x, y, z, x + 1.0, y + 0.6, z + 1.0), -227217056);
            }
        }
	}

}
