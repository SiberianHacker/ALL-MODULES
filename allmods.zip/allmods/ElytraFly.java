package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;

import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class ElytraFly extends Module {

	public ElytraFly() {
		super("ElytraFly", Keyboard.KEY_NONE, ModuleType.Player);
	}
	
	public void onUpdate() {
		
	}
}
