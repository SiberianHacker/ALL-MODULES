package ru.ShwepsikGG.Cleent.Modules;
import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import ru.ShwepsikGG.Cleent.CommandManager;
import ru.ShwepsikGG.Cleent.EClient;
import ru.ShwepsikGG.Cleent.BotGui.Panel;
import ru.ShwepsikGG.Cleent.HeroGui.ClickGUI;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class BotGui extends Module{

	public BotGui() {
		super("BotsGui", Keyboard.KEY_EQUALS, ModuleType.Exploit);
	}
	
	Minecraft mc = Minecraft.getMinecraft();
	
	public void onEnable() {
		toggle();
		mc.displayGuiScreen(new Panel());
	}
	

}
