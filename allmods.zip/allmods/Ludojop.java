package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class Ludojop extends Module {

	public Ludojop() {
		super("Лудожоп", Keyboard.KEY_NONE, ModuleType.Fun);
	}
	
	public void onUpdate() {
		Minecraft mc = Minecraft.getMinecraft();
		mc.player.motionY += 0.07;
	}
}
