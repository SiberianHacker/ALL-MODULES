package rawfish2d.client.pbot.modules;

import rawfish2d.client.modulebase.ModuleType;
import rawfish2d.client.pbot.PBot;
import rawfish2d.client.pbot.modulebase.PBotModuleBase;

public class AutoRegister extends PBotModuleBase {
    public static boolean reg = false;
    public AutoRegister(String name, String desc, int keybind, ModuleType type, final PBot pbot) {
        super(name, desc, keybind, type, pbot);
    }

    @Override
    public void onEnable() {
        this.reg = true;
    }

    @Override
    public void onDisable() {
        this.reg = false;
    }
}
