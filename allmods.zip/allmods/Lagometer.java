package ru.ShwepsikGG.Cleent.Modules;

import java.awt.Color;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class Lagometer extends Module {

	private float tps;
	private double lastTimePacketReceived;

	public Lagometer() {
		super("LagDetector", Keyboard.KEY_NONE, ModuleType.Render);
	}
	
	public void onRender2D() {
		Minecraft.getMinecraft().fontRendererObj.drawString("TPS is " + tps, "ExtremeHack B17.5".length() +100, 3, Color.YELLOW.hashCode());
	}
	
	public void onEnable() {
		
	}
	
	public void onLastPacket() {
		if(this.packet instanceof SPacketTimeUpdate) {
			float tmp = (float)(this.calculateTps((double)System.currentTimeMillis() - this.lastTimePacketReceived) * 100.0D);
	        this.tps = tmp / 100.0F;
	        this.lastTimePacketReceived = (double)System.currentTimeMillis();
		}
	}
	
	private double calculateTps(double n) {
		return 20.0D / Math.max((n - 1000.0D) / 500.0D, 1.0D);
	}

}
