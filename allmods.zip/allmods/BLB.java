package rawfish2d.client.pbot.modules;

import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import rawfish2d.client.modulebase.ModuleType;
import rawfish2d.client.pbot.PBot;
import rawfish2d.client.pbot.modulebase.PBotModuleBase;
import rawfish2d.client.utils.MiscUtils;
import rawfish2d.utils.TimeHelper;

public class BLB extends PBotModuleBase {
	private TimeHelper time = new TimeHelper();
	private boolean runModuleLater = false;

	public BLB(String name, String desc, int keybind, ModuleType type, final PBot pbot) {
		super(name, desc, keybind, type, pbot);
	}

	@Override
	public void onEnable() {

	}

	@Override
	public void onDisable() {

	}

	@Override
	public void onPreUpdate() {
		if (!runModuleLater && time.hasReached(5000)) {
			if (pbot.player.openContainer == null) {
				pbot.botInfoPrint("wtf??...");
				runModuleLater = true;
			}
		}
		if (runModuleLater && time.hasReached(1000)) {
			runModuleLater = false;
			pbot.player.rotationPitch = MiscUtils.random(-5f, 5f);
			pbot.player.rotationYaw = MiscUtils.random(-5f, 5f) + 180;
			pbot.mc.gameSettings.keyBindForward.pressed = true;
			pbot.botInfoPrint("running...");
		}
		if (pbot.player.posZ < 69f) {
			pbot.botInfoPrint("running stop, clicking");
			pbot.mc.gameSettings.keyBindForward.pressed = false;
			BlockPos pos = new BlockPos(-2, 89, 65);
			pbot.sendPacket(new CPacketPlayerTryUseItemOnBlock(pos, EnumFacing.SOUTH, EnumHand.MAIN_HAND, 0.5721997f, 0.45766628f, 0.0625f));
			this.disable();
		}
    }

	@Override
	public boolean onPacket(Packet packet) {
		if (packet instanceof SPacketChat) {
			SPacketChat p = (SPacketChat) packet;
			// BotFilter>> �������� ��������, �������� ����!
			/*
			//String text = MiscUtils.removeFormatting(p.getChatComponent().getFormattedText());
			if (text.contains("�������� ��������, �������� ����!")) {
				pbot.botInfoPrint("chat message OK");
				runModuleLater = true;
				time.reset();
			}
			*/
			runModuleLater = true;
			time.reset();
		}
		return true;
	}
}
