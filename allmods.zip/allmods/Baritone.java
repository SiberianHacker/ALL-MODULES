package ru.ShwepsikGG.Cleent.Modules;
import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import ru.ShwepsikGG.Cleent.CommandManager;
import ru.ShwepsikGG.Cleent.EClient;
import ru.ShwepsikGG.Cleent.BotGui.Panel;
import ru.ShwepsikGG.Cleent.HeroGui.ClickGUI;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class Baritone extends Module{

	public Baritone() {
		super("Баритон", Keyboard.KEY_NONE, ModuleType.Fun);
	}
	
	Minecraft mc = Minecraft.getMinecraft();
	
	public void onEnable() {
	}
	

}
