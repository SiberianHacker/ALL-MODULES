package ru.ShwepsikGG.Cleent.Modules;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.command.ICommand;
import net.minecraft.entity.player.EntityPlayer;
import ru.ShwepsikGG.Cleent.ModuleSystem.Module;
import ru.ShwepsikGG.Cleent.ModuleSystem.ModuleType;

public class DragonWings extends Module {
	
    
	
	public DragonWings() {
		super("Dragon Wings", Keyboard.KEY_NONE, ModuleType.Fun);
	}
	
	public void onEnable() {
	}
	
	public void onDisable() {
	}
	
	Minecraft mc = Minecraft.getMinecraft();
	
	public void onRender3D() {
		
		RenderWings wing = new RenderWings();
		wing.onRenderPlayer();
	}
}
